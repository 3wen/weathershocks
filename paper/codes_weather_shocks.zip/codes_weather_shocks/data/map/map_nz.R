# This file is used to create an R data object representing NZ maps:
# - nz_df_regions.rda
# It is a tbl_df() that contains coordinates of points
# to delimit polygons for each NZ region.

library(rgdal)
library(maptools)
library(ggplot2)
library(plyr)
library(dplyr)


# Source: Statistics NZ
# Place the extracted file in the folder `2015 Digital Boundaries Generalised Clipped`
# http://www3.stats.govt.nz/digitalboundaries/annual/ESRI_Geodatabase_2015_Digital_Boundaries_Generalised_Clipped.zip
nz <- readOGR(dsn="2015 Digital Boundaries Generalised Clipped/",
              layer="REGC2015_GV_Clipped")
nz <- spTransform(nz, CRS("+proj=longlat +ellps=GRS80"))
nz_points <- fortify(nz)
nz@data$id <- rownames(nz@data)
nz_df <- join(nz_points, nz@data, by="id")
head(nz_df)

library(stringr)
nz_df <- nz_df %>% 
 mutate(region = REGC2015_N %>% str_replace(" Region$", ""),
        long = round(long, 2),
        lat = round(lat, 2)) %>% 
  select(long, lat, group, region) %>% 
  group_by(region) %>% 
  do(., unique(.)) %>% 
  filter(long < 185, long > 162, lat < -32, lat > -50) %>% 
  ungroup()


# ggplot(data = nz_df, aes(x = long, y = lat, group = group)) + geom_polygon() +
#   coord_quickmap()


regions <- 
  c("Northland", "Auckland", "Waikato", "Bay of Plenty", "Gisborne",
    "Hawke's Bay", "Taranaki", "Manawatu-Wanganui", "Wellington",
    "West Coast", "Canterbury", "Otago", "Southland", "Marlborough", "Tasman/Nelson")


regions_carte <- nz_df$region %>% unique

regions[which(!regions %in% regions_carte)]


nz_df_regions <- 
  nz_df %>% 
  mutate(region = ifelse(region %in% c("Tasman", "Nelson"), yes = "Tasman/Nelson", no = region))

ggplot(data = nz_df_regions, aes(x = long, y = lat, group = group)) + geom_polygon() +
  coord_quickmap()

save(nz_df_regions, file="nz_df_regions.rda")

