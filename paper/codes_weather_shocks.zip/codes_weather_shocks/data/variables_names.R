library(latex2exp)
library(dplyr)
# Variable internal names and sexier names
# corresp_names <- matrix(ncol=4, byrow=TRUE, c(
#   "wy_obs", "World Production $\\hat{y}^F_t$", "$\\hat{y}^F_t$", "hat(y)[t]^F",
#   "wp_obs", "World Inflation $\\hat{\\pi}_t^F$", "$\\hat{\\pi}_t^F$", "hat(pi)[t]^F",
#   "wr_obs", "World Nominal Rate $\\hat{r}_t^F$", "$\\hat{r}_t^F$", "hat(r)[t]^F",
#   "y_obs", "Production $\\hat{y}_t$", "$\\hat{y}_t$", "hat(y)[t]",
#   "y_a_obs", "Ag. Production $\\hat{y}_t^A$", "$\\hat{y}_t^A$", "hat(y)[t]^A",
#   "p_obs", "Inflation $\\hat{\\pi}_t$", "$\\hat{\\pi}_t$", "hat(pi)[t]",
#   "p_a_obs", "Ag. Inflation $\\hat{\\pi}_t^A$", "$\\hat{\\pi}_t^A$", "hat(pi)[t]^A",
#   "ex_rate_obs", "Exchange Rate $\\hat{e}_t$", "$\\hat{e}_t$", "hat(e)[t]",
#   "r_obs", "Nominal Rate $\\hat{r}_t$", "$\\hat{r}_t$", "hat(r)[t]",
#   "smdi_obs", "Soil Moisture Deficit Index $\\hat{s}_t$", "$\\hat{s}_t$", "hat(s)[t]",
#   "r_y_hp", "Production $y$", "$y_t$", "y[t]",
#   "r_y_a_hp", "Ag. Production $y^A$", "$y_t^A$", "y[t]^A"
# ))

corresp_names <- matrix(ncol=4, byrow=TRUE, c(
  "wy_obs", "Foreign Output", "$\\Delta log\\left(Y_t^*\\right)$", "hat(y)[t]^F",
  "wp_obs", "Foreign CPI Inflation", "$\\pi_t^*$", "hat(pi)[t]^F",
  "wr_obs", "Foreign Interest Rate", "r_t^*", "hat(r)[t]^F",
  "wp_a_obs", "Foreign Ag. Price Infl.", "\\Delta log \\left(p_t^{A*}\\right)$", "p[t]^D",
  "wy_a_obs", "Foreign Ag. Output", "$\\Delta log \\left(Y_t^{A*}\\right)$", "Y[t]^D",
  "oil_obs", "Crude Oil Inflation", "$oil_t$", "hat(oil)[t]",
  "y_obs", "Output", "$\\Delta log \\left(Y_t^d\\right)$", "hat(y)[t]",
  "y_a_obs", "Ag. Output", "$\\Delta log \\left(X_t^A\\right)$", "hat(y)[t]^A",
  "p_obs", "CPI Inflation", "$\\pi_t^C$", "hat(pi)[t]",
  "ratio_p_obs", "Rel. Prices", "$\\pi_{x,t}^A / \\pi_t^C$", "hat(pi)[t] / hat(pi)[t]^A",
  "p_a_obs", "Ag. Inflation", "$log \\left(\\pi_{x,t}^A\\right)$", "hat(pi)[t]^A",
  "c_obs", "Consumption", "$log \\left(c_{t}\\right)$", "hat(c)[t]",
  "h_obs", "Hours Worked", "\\Delta log \\left($h_t\\right)$", "hat(h)[t]",
  "i_obs", "Investment", "$\\Delta log \\left(i_t\\right)$", "hat(i)[t]",
  "q_obs", "Stock Prices", "q_t", "hat(q)[t]",
  "im_obs", "Imports", "\\Delta log \\left(im_{t}\\right)$", "hat(im)[t]",
  "x_obs", "Exports", "$\\Delta log \\left(x_{t}\\right)$", "hat(x)[t]",
  "tb_obs", "Trade Balance", "$tb_{t}$", "hat(tb)[t]",
  "ex_rate_obs", "Real Ex. Rate", "$rer_t$", "hat(e)[t]",
  "reer_obs", "Real Eff. Ex. Rate", "$reer_$", "hat(e)[t]",
  "r_obs", "Interest Rate", "$r_t$", "hat(r)[t]",
  "smdi_obs", "Weather", "$\\varepsilon_{t}^{W}$", "hat(s)[t]",
  "r_y_hp", "GDP Deviation From HP Filter Trend", "$y_t$", "y[t]",
  "r_y_a_hp", "agricultural GDP Deviation From HP Filter Trend", "$y_t^A$", "y[t]^A",
  "smdi", "Wheater", "$\\varepsilon_{t}^{W}$", "hat(s)[t]",
  "y_w", "Foreign Output", "$\\Delta log\\left(Y_t^*\\right)$", "hat(y)[t]^F",
  "y", "Output", "$\\Delta log \\left(Y_t^d\\right)$", "hat(y)[t]"
))



corresp_names <- corresp_names %>% data.frame(stringsAsFactors = FALSE)
colnames(corresp_names) <- c("name_r", "long_name", "short_name", "pm_name")

# cat(str_c('"', corresp_names$name_r, '"'), sep = ", ")

noms_ordonnees <- corresp_names$name_r

# On change l'ordre pour les facteurs
corresp_names <- 
  corresp_names %>% 
  mutate(name_r = factor(name_r,
                         levels = noms_ordonnees))



# Retourne le nom de la serie dans un format plus sexy
c_name <- function(x, type = c("pm", "short", "long")){
  type <- match.arg(type)
  type <- type %>% str_c("_name")
  ind <- match(x, corresp_names[,"name_r"])
  corresp_names[ind, type]
}

# x <- "pi_agri"
# Retourne le nom de la serie dans un format plus sexy
c_name_2 <- function(x){
  ind <- match(x, corresp_names[,"name_r"])
  nom <- str_extract(corresp_names[ind, "long_name"], "^(.*?)\\$") %>% 
    str_sub(1, -2) %>% 
    str_trim() %>% 
    str_replace_all(" ", "~")
  nom_2 <- corresp_names[ind, "pm_name"]
  str_c(nom, "~(", nom_2, ")")
}

# Tous les groupes de 2 possibles
possibilites <- expand.grid(levels(corresp_names$name_r),
                            levels(corresp_names$name_r)) %>% 
  arrange(Var1, Var2) %>% 
  mutate(title = str_c(Var1, "-", Var2))

size_text <- 20
library(grid)
theme_paper <- function(...)
  theme(text = element_text(size = size_text),
        panel.background = element_rect(fill = NA),
        #panel.border = element_rect(fill = NA, colour = "grey50", size = 1),
        axis.line = element_line(colour = "grey60"),
        axis.title = element_blank(), axis.text = element_text(), 
        # axis.text = element_text(colour = "#7F7F7F"),
        #axis.ticks = element_blank(), axis.line = element_blank(),
        legend.text = element_text(size = rel(1.1)),
        legend.title = element_text(size = rel(1.1)),
        legend.background = element_rect(), legend.position = "bottom", 
        legend.direction = "horizontal", legend.box = "vertical",
        panel.spacing = unit(1, "lines"),
        panel.grid.major = element_line(colour = "grey90"), 
        #panel.grid.minor = element_line(colour = "grey90"),
        panel.grid.minor = element_blank(),
        plot.title = element_text(hjust = 0, size = rel(1.3), face = "bold"),
        plot.margin = unit(c(1, 1, 1, 1), "lines"),
        strip.background = element_rect(fill=NA, colour = NA),
        strip.text = element_text(size = rel(1.1)))


theme_map_paper <- function(...)
  theme(text = element_text(size = size_text),
      panel.background = element_blank(),
      panel.border = element_blank(),
      #axis.line = element_line(colour = "grey60"),
      axis.title = element_blank(),
      axis.text = element_blank(),
      axis.ticks = element_blank(), axis.line = element_blank(),
      legend.text = element_text(size = rel(1.2)),
      legend.title = element_text(size = rel(1.2)),
      legend.background = element_rect(),
      legend.key.height	= unit(2, "line"),
      legend.key.width	= unit(3, "line"),
      strip.background = element_rect(fill=NA),
      #legend.position = "bottom", 
      #legend.direction = "horizontal", legend.box = "vertical",
      panel.spacing = unit(1, "lines"),
      panel.grid.major = element_blank(),
      #panel.grid.minor = element_line(colour = "grey90"),
      panel.grid.minor = element_blank(),
      plot.margin = unit(c(1, 1, 1, 1), "lines"),
      strip.text = element_text(size = rel(1.2)))
