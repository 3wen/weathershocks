# Codes to replicate the content of the article:
# "Weather Shocks"
# 2019

# This files imports World data in R and exports them as an R data file.
# The objectif is to obtain data of GDP, interest rate and prices for NZ leading trade partners.
# An Internet connexion is needed.

# Objective :
# Creates a data frame of GDP, Interest Rate and CPI for NZ trading partners
# (Australia, China, USA, Japan, Korea, UK, Germany)
# wgdp: sum of GDP of largest partners
# r: short term interest rate (weighted mean of interest rates, weights equal to share of trade)
# cpi: consummer price index (weighted mean of cpi, weights equal to share of trade)

# This package is very useful: when you try to load another package
# if it is missing, pacman will try to install it.
# install.packages("pacman")
library(pacman)

p_load(dplyr, stringr, readxl, tidyr, ggplot2)

source("variables_names.R")

# Setting the reference year for index creation
ref_year <- 2010


p_load(OECD)

country_ref <- 
  data.frame(LOCATION = c("AUS", "JPN", "USA", "GBR", "DEU"),
             country = c("Australia", "Japan", "United States", "United Kingdom", "Germany"))

## ====================== ##
## GROSS DOMESTIC PRODUCT ##
## ====================== ##

# VPVOBARSA: US dollars, volume estimates, fixed PPPs,
# OECD reference year (2010), annual levels, seasonally adjusted

df_gdp <- get_dataset("QNA",
                      filter = "AUS+JPN+GBR+USA+DEU.B1_GE.VPVOBARSA.Q",
                      pre_formatted = TRUE)

df_gdp <- 
  df_gdp %>% 
  left_join(country_ref) %>% 
  mutate(year = str_sub(obsTime, 1, 4),
         quarter = str_sub(obsTime, -1),
         YEARS = as.numeric(year) + (as.numeric(quarter)-1)/4) %>% 
  rename(gdp = obsValue) %>% 
  select(YEARS, country, gdp)

p <- ggplot(data = df_gdp, aes(x = YEARS, y = gdp, colour = country)) +
  geom_line() +
  xlab("") +
  ylab("") +
  ggtitle("GDP (PPP, millions $, constant 2010 prices)") +
  scale_colour_discrete("") +
  theme_paper()
p

df_gdp %>% 
  group_by(country) %>% 
  summarise(min_y = min(YEARS), max_y = max(YEARS), n = n())


## ============= ##
## INTEREST RATE ##
## ============= ##

# interest_rates <- get_dataset("MEI_FIN",
#                               filter = "IR3TIB.AUS+JPN+GBR+USA.Q",
#                               pre_formatted = TRUE)

interest_rates <- get_dataset("EO100_INTERNET",
                              filter = "AUS+JPN+GBR+USA+DEU.IRS.Q",
                              pre_formatted = TRUE)


df_r <- 
  interest_rates %>% 
  left_join(country_ref) %>% 
  mutate(year = str_sub(obsTime, 1, 4),
         quarter = str_sub(obsTime, -1),
         YEARS = as.numeric(year) + (as.numeric(quarter)-1)/4) %>% 
  rename(r = obsValue) %>% 
  select(YEARS, country, r)


p <- ggplot(data = df_r, aes(x = YEARS, y = r, colour = country)) +
  geom_line() +
  xlab("") +
  ylab("") +
  ggtitle("Short-Term Interest Rate") +
  scale_colour_discrete("") +
  theme_paper()
p


df_r <- df_r %>% filter(!is.na(r))

df_r %>% 
  group_by(country) %>% 
  summarise(min_y = min(YEARS), max_y = max(YEARS), n = n())


## ==================== ##
## CONSUMER PRICE INDEX ##
## ==================== ##

# Consumer prices - all items
# Index, 2010=100

cpi <- get_dataset("MEI_PRICES",
                   filter = "CPALTT01.AUS+JPN+GBR+USA+DEU.IXOB.Q",
                   pre_formatted = TRUE)

df_cpi <- 
  cpi %>% 
  left_join(country_ref) %>% 
  mutate(year = str_sub(obsTime, 1, 4),
         quarter = str_sub(obsTime, -1),
         YEARS = as.numeric(year) + (as.numeric(quarter)-1)/4) %>% 
  rename(cpi = obsValue) %>% 
  select(YEARS, country, cpi)


p <- ggplot(data = df_cpi, aes(x = YEARS, y = cpi, colour = country)) +
  geom_line() +
  xlab("") +
  ylab("") +
  ggtitle("CPI") +
  scale_colour_discrete("") +
  theme_paper()
p


df_cpi <- df_cpi %>% filter(!is.na(cpi))

df_cpi %>% 
  group_by(country) %>% 
  summarise(min_y = min(YEARS), max_y = max(YEARS), n = n())


## ======== ##
## DEFLATOR ##
## ======== ##

# Consumer prices - all items
# Index, 2010=100

gdp_defl <- get_dataset("QNA",
                   filter = "AUS+JPN+GBR+USA+DEU.B1_GE.DOBSA.Q",
                   pre_formatted = TRUE)



df_gdp_defl <- 
  gdp_defl %>% 
  left_join(country_ref) %>% 
  mutate(year = str_sub(obsTime, 1, 4),
         quarter = str_sub(obsTime, -1),
         YEARS = as.numeric(year) + (as.numeric(quarter)-1)/4) %>% 
  rename(gdp_defl = obsValue) %>% 
  select(YEARS, country, gdp_defl)


p <- ggplot(data = df_gdp_defl, aes(x = YEARS, y = gdp_defl, colour = country)) +
  geom_line() +
  xlab("") +
  ylab("") +
  ggtitle("GDP Deflator") +
  scale_colour_discrete("") +
  theme_paper()
p


df_gdp_defl <- df_gdp_defl %>% filter(!is.na(gdp_defl))

df_gdp_defl %>% 
  group_by(country) %>% 
  summarise(min_y = min(YEARS), max_y = max(YEARS), n = n())



library(tempdisagg)

# Estimate quarterly data from annual data
# Method: denton-cholette

#' yearly_to_quarterly
#' 
#' Function to convert annual data y_yearly to quarterly serie.
#' It uses the variations of the quarterly serie x_quarterly to help fitting
#' @y_yearly : annual data
#' @x_quarterly : quarterly data
#' @y_year_start : start year for annual data
#' @x_year_start : start year for quarterly data
#' @x_quarter_start : start quarter for quarterly data
#' @nom_y : name of annual data
yearly_to_quarterly <- function(y_yearly, x_quarterly,
                                y_year_start, x_year_start, x_quarter_start, nom_y){
  y <- ts(y_yearly, start = y_year_start, frequency = 1)
  x <- ts(x_quarterly, start = c(x_year_start, x_quarter_start), frequency = 4)
  modele <- td(y ~ x)
  y_pred <- predict(modele)
  res <- data.frame(years = as.vector(time(y_pred)), value = as.vector(y_pred))
  colnames(res)[2] <- nom_y
  res
}# End of yearly_to_quarterly()

## ========== ##
## POPULATION ##
## ========== ##

# Population 15-64
# Persons, Thousands

pop <- get_dataset("ALFS_POP_LABOUR",
                   filter = "AUS+JPN+GBR+USA+DEU.YP99P2L1_ST.TT.A",
                   pre_formatted = TRUE)

pop <- 
  pop %>% 
  left_join(country_ref) %>% 
  rename(pop = obsValue, year = obsTime) %>% 
  select(year, country, pop)



the_country <- "United Kingdom"

library(tempdisagg)
pop_quarterly <- function(the_country){
  x <- pop %>%
    filter(country %in% the_country)
  x_ts <- ts(x$pop, start = as.numeric(x$year[1]))
  # Forecast 3 years ahead
  x_f <- forecast::forecast(forecast::auto.arima(x_ts), h = 3)
  # Disaggregate
  x_ts <- ts(c(x_ts, x_f$mean), start = start(x_ts))
  res <- predict(td(x_ts ~ 1, method = "denton-cholette", conversion = "average"))
  res <- data.frame(YEARS = as.vector(time(res)), country = the_country, pop = as.vector(res))
  
  # Change base year
  ref_pop <- res %>% filter(YEARS == ref_year) %>% .$pop
  
  res %>% 
    mutate(pop = pop / ref_pop * 100)
}

df_pop <- 
  lapply(unique(pop$country), pop_quarterly) %>% 
  bind_rows() %>% 
  tbl_df()


p <- ggplot(data = df_pop, aes(x = YEARS, y = pop, colour = country)) +
  geom_line() +
  xlab("") +
  ylab("") +
  ggtitle("CPI") +
  scale_colour_discrete("") +
  theme_paper()
p


df_pop <- df_pop %>% filter(!is.na(pop))

df_pop %>% 
  group_by(country) %>% 
  summarise(min_y = min(YEARS), max_y = max(YEARS), n = n())


# =========================== #
# GDP, INFLATION RATE AND CPI #
# =========================== #

shares <- 
  df_gdp %>% 
  spread(country, gdp) %>% 
  mutate(total_gdp = Australia + Germany + Japan + `United Kingdom` + `United States`) %>% 
  filter(YEARS >= 1987, YEARS < 2017) %>% 
  mutate(share_Australia = Australia / total_gdp,
         share_Germany = Germany / total_gdp,
         share_Japan = Japan / total_gdp,
         `share_United Kingdom` = `United Kingdom` / total_gdp,
         `share_United States` = `United States` / total_gdp) %>% 
  select(YEARS, share_Australia:`share_United States`) %>% 
  gather(country, share, -YEARS) %>% 
  mutate(country = str_sub(country, nchar("share_")+1))
  
  

df <- 
  df_gdp %>% 
  left_join(df_r, by = c("YEARS", "country")) %>% 
  left_join(df_cpi, by = c("YEARS", "country")) %>% 
  left_join(df_gdp_defl, by = c("YEARS", "country")) %>% 
  left_join(df_pop, by = c("YEARS", "country")) %>% 
  left_join(shares, by = c("YEARS", "country")) %>% 
  rename(years = YEARS) %>% 
  filter(years >= 1987, years < 2017)


df <- 
  df %>% 
  mutate(prices = gdp_defl)

df_w <- 
  df %>% 
  mutate(r_y = gdp / pop / prices) %>% 
  mutate(r_y = r_y * share,
         cpi = cpi * share,
         gdp_defl = gdp_defl * share,
         r = r * share) %>% 
  group_by(years) %>% 
  summarise(wgdp = sum(r_y),
            wcpi = sum(cpi),
            wgdp_def = sum(gdp_defl),
            wr = sum(r))


save(df_w, file = "economic_data/df_w.rda")
