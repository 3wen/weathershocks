library(RNetCDF)
#library(ncdf4)
library(lubridate)
library(plyr)
library(dplyr)
library(stringr)
library(tidyr)
library(ggplot2)


library(extrafont)
library(fontcm)
loadfonts(quiet = TRUE)

afficher_graph <- FALSE

set.seed(1)

# SOURCE : http://www.cses.washington.edu/rocinante/CMIP5/historical/CCSM4/


extract_var <- function(fichier, dname, debut){
  nc <-
    fichier %>%
    open.nc
  
  # Longitudes
  lon <- var.get.nc(nc,"lon")
  nlon <- dim(lon)
  # Latitudes
  lat <- var.get.nc(nc,"lat")
  nlat <- dim(lat)
  # Nombre de jours depuis l'origine
  time <- var.get.nc(nc,"time")
  # Unite temporelle
  tunits <- att.get.nc(nc, "time", "units")
  # Temps (utile pour le nom des colonnes)
  orig <- ymd_hms(str_replace(tunits, "days since ", ""))
  
  date_debut_donnees <- 
    str_extract(fichier, "r1i1p1_(.*?)$") %>% 
    str_sub(8, -11)
  date_debut_donnees <- 
    date_debut_donnees %>% str_sub(1,4) %>% as.numeric() +
    date_debut_donnees %>% str_sub(5) %>% as.numeric() / 12 - 1/12
  
  dates <- date_debut_donnees + rep(seq(12), length.out = length(time)) / 12 - 1/12
  dates <- dates + rep(seq(0, (length(dates)-1) / 12), each = 12)
  
  ind_conserver <- which(dates >= debut)
  dates_conserver <- dates[ind_conserver]
  # Dimension temporelle
  ntime <- length(dates_conserver)
  
  
  # L'indice de la premiere date a conserver
  commencement <- ind_conserver[1]
  
  # On recupere alors les donnees (en evitant de tout recuperer avant 1986 !)
  tab_val <- var.get.nc(nc, dname, start=c(1,1,commencement), count = c(NA,NA, length(ind_conserver)))
  # Le nom de la variable (etiquette)
  d_l_name <- att.get.nc(nc, dname, "long_name")
  # L'unite de la variable
  d_units <- att.get.nc(nc, dname, "units")
  # La valeur des NAs
  fill_value <- att.get.nc(nc, dname, "_FillValue")
  # On replace
  tab_val[tab_val == fill_value] <- NA
  # =
  # Meta data
  # =
  
  #title <- att.get.nc(nc, 0, "title")
  #institution <- att.get.nc(nc, 0, "institution")
  #datasource <- att.get.nc(nc, 0, "source")
  #references <- att.get.nc(nc, 0, "references")
  #history <- att.get.ncdf(nc, 0, "history")
  #conventions <- att.get.ncdf(nc, 0, "Conventions")
  
  # Les valeurs
  tab_val_vect <- as.vector(tab_val)
  tab_val_mat <- matrix(tab_val_vect, nrow = nlon * nlat, ncol = ntime)
  
  lon_lat <- expand.grid(lon, lat)
  lon_lat <- lon_lat %>% mutate(Var1 = as.vector(Var1), Var2 = as.vector(Var2))
  
  res <- data.frame(cbind(lon_lat, tab_val_mat))
  
  
  noms <- str_c(dates_conserver %/% 1,
                round((dates_conserver %% 1 + 1/12)*12),
                sep = "_")
  
  names(res) <- c("lon", "lat", noms)
  res <-
    res %>%
    mutate(lon = ifelse(lon >= 180, yes = lon - 360, no = lon)) %>%
    filter(lon < 185, lon > 162, lat < -32, lat > -50) %>% # On se restreint a la NZ
    gather(key, value, -lon, -lat) %>%
    separate(key, into = c("year", "month"), sep="_")
  list(data = res, unit = d_units, name = d_l_name)
}# Fin de extract_var()


# ======================================= #
# PRECIPITATION #
# ======================================= #

## HISTORICAL ##
# ============ #

import_precip_year <- function(fichier, debut){
  precip <- extract_var(fichier = fichier, dname = "pr", debut=debut)
  
  print(ts_nom <- precip$name)
  # Les precipitations sont en kg m2/s
  print(ts_unit <- precip$unit)
  
  precip <- precip$data
  
  # Conversion en mm
  precip <-
    precip %>%
    mutate(value = value * 3600 * 24 * 30,
           month = as.numeric(month),
           year = as.numeric(year))
  
  precip <- precip %>% tbl_df()
}# Fin de import_precip_year()


N <- dir("projections/", pattern = "^pr_Amon", full.names = TRUE)

precip <- import_precip_year(fichier = "projections/pr_Amon_CCSM4_historical_r1i1p1_185001-200512.nc", debut = 1960)

# Les donnees historiques, par annees
# precip

# # Moyenne sur la periode 1986-2005
precip_moy_hist <- precip %>%
  filter(year >= 1986, year <= 2005) %>%
  group_by(lon, lat, month) %>%
  summarise(precip = mean(value, na.rm = TRUE)) %>%
  ungroup

ggplot(data =
         precip %>% 
         group_by(month) %>% 
         summarise(moy = mean(value)), aes(x = factor(month), y = moy)) +
  geom_bar(stat = "identity")



## RCP 2.6 ##
# ========= #

precip_rcp26 <- import_precip_year(fichier = "projections/pr_Amon_CCSM4_rcp26_r1i1p1_200601-210012.nc", debut = 2006)

## RCP 4.5 ##
# ========= #

precip_rcp45 <- import_precip_year(fichier = "projections/pr_Amon_CCSM4_rcp45_r1i1p1_200601-210012.nc", debut = 2006)

## RCP 6.0 ##
# ========= #

precip_rcp60 <- import_precip_year(fichier = "projections/pr_Amon_CCSM4_rcp60_r1i1p1_200601-210012.nc", debut = 2006)


## RCP 8.5 ##
# ========= #

precip_rcp85 <- import_precip_year(fichier = "projections/pr_Amon_CCSM4_rcp85_r1i1p1_200601-210012.nc", debut = 2006)



# Rassemblement des cinq mesures

precip <- precip %>% mutate(type = "hist")
precip_rcp26 <- precip_rcp26 %>% mutate(type = "rcp26")
precip_rcp45 <- precip_rcp45 %>% mutate(type = "rcp45")
precip_rcp60 <- precip_rcp60 %>% mutate(type = "rcp60")
precip_rcp85 <- precip_rcp85 %>% mutate(type = "rcp85")


precip_all <- 
  precip %>% 
  bind_rows(
    precip_rcp26 %>% 
      bind_rows(precip_rcp45) %>% 
      bind_rows(precip_rcp60) %>% 
      bind_rows(precip_rcp85))

# Pour chaque idRegion, il faut qu'on regarde quels sont les points de la grille climat_cm3 qui sont dedans

devtools::install_github("rdpeng/gpclib")
library(gpclib)
library(surveillance)

grille <- precip_all %>%
  filter(year == precip_all$year[1]) %>% 
  select(lon, lat) %>%
  unique %>%
  mutate(xmin = lon - 1.25,
         xmax = lon + 1.25,
         ymin = lat - 1,
         ymax = lat + 1)

grille$id <- 1:nrow(grille)

# Ajout des IDs des grilles aux data.frames


precip_all <- 
  precip_all %>% 
  left_join(grille %>% select(lon, lat, id))

# Cellules de la grille en gpc.poly
grille_gpc <- list()
pb <- txtProgressBar(min = 1, max = nrow(grille))
for(i in 1:nrow(grille)){
  cell <- grille[i,]
  grille_gpc[[i]] <- matrix(c(cell$xmin, cell$xmin, cell$xmax, cell$xmax,
                              cell$ymin, cell$ymax, cell$ymax, cell$ymin), ncol = 2) %>%
    as("gpc.poly")
  setTxtProgressBar(pb, i)
}



# nz_df$id_region <- "nz"
# Carte des regions de NZ
load("../../map/nz_df_regions.rda")


region_as_gpc_poly <- function(id_region){
  
  carte_tmp <- nz_df_regions %>%
    filter(region == id_region)
  
  polys_fadn <-
    plyr::dlply(carte_tmp, .(group), function(x){
      x %>% select(long, lat) %>% data.frame %>% as("gpc.poly")
    })
  
  # Il ne reste plus qu'a recuperer l'union de tous ces polygones
  polygone_fadn <- polys_fadn[[1]]
  if(length(polys_fadn) > 1){
    for(i in 2:length(polys_fadn)){
      polygone_fadn <- gpclib::union(polygone_fadn, polys_fadn[[i]])
    }
  }
  polygone_fadn
}


regions_poly <- lapply(unique(nz_df_regions$region), region_as_gpc_poly)
polygone_nz <- regions_poly[[1]]
for(i in 2:length(regions_poly)){
  polygone_nz <- gpclib::union(polygone_nz, regions_poly[[i]])
}

# plot(polygone_nz)


intersections_grille <- lapply(grille_gpc, function(x) gpclib::area.poly(gpclib::intersect(x, polygone_nz)))
intersections_grille <- unlist(intersections_grille)
intersections_grille <- data.frame(area = intersections_grille)
intersections_grille$id <- grille$id

intersections_grille <-
  intersections_grille %>%
  filter(area > 0) #%>%




ggplot(data = 
         precip_all %>% 
         filter(id %in% intersections_grille$id) %>% 
         filter(type %in% c("hist", "rcp85")) %>% 
         filter(year %in% c(1986:2005, 2081:2100)) %>% 
         group_by(type, id, lon, lat) %>% 
         summarise(value = mean(value)),
       aes(x = lon, y = lat, fill = value)) + geom_raster() +
  geom_polygon(data = nz_df_regions, aes(x = long, y = lat, group = group), fill=NA, col = "black")+
  coord_quickmap() +
  facet_wrap(~type)


ggplot(data = 
         precip_all %>% 
         filter(id %in% intersections_grille$id) %>% 
         filter(type %in% c("hist", "rcp85")) %>% 
         filter(year %in% c(1986:2005, 2081:2100)) %>% 
         group_by(type, id, lon, lat) %>% 
         summarise(value = mean(value)) %>% 
         spread(type, value) %>% 
         mutate(difference = rcp85 - hist),
       aes(x = lon, y = lat, fill = difference)) + geom_raster() +
  geom_polygon(data = nz_df_regions, aes(x = long, y = lat, group = group), fill=NA, col = "black")+
  scale_fill_gradient2(low = "red", mid = "white", high = "green") +
  coord_quickmap()




#id_region <- "Waikato"
#rm(id_region, carte_tmp, polys_fadn, polygone_fadn,intersections_grille, hist, proj, agreg)
# Pour chaque id_region, retourne la valeur climatique
# comme une moyenne ponderee des observations de chaque grille
# le poids etant la proportion de la cellule de la grille en intersection avec la region
cells_f <- function(id_region){
  
  carte_tmp <- nz_df_regions %>%
    filter(region == id_region)
  
  polys_fadn <-
    plyr::dlply(carte_tmp, .(group), function(x){
      x %>% select(long, lat) %>% data.frame %>% as("gpc.poly")
    })
  
  # Il ne reste plus qu'a recuperer l'union de tous ces polygones
  polygone_fadn <- polys_fadn[[1]]
  if(length(polys_fadn) > 1){
    for(i in 2:length(polys_fadn)){
      polygone_fadn <- gpclib::union(polygone_fadn, polys_fadn[[i]])
    }
  }
  
  
  
  # Les surfaces d'intersection entre chaque cellule et la region
  intersections_grille <- lapply(grille_gpc, function(x) gpclib::area.poly(gpclib::intersect(x, polygone_fadn)))
  intersections_grille <- unlist(intersections_grille)
  
  intersections_grille <- data.frame(area = intersections_grille)
  intersections_grille$id <- grille$id
  
  intersections_grille <-
    intersections_grille %>%
    filter(area > 0) #%>%
  #mutate(pct_area = area / sum(area))
  #   
  
  # Donnees par annee, mois, region #
  # ------------------------------- #
  
  precip_all %>% 
    filter(id %in% intersections_grille$id) %>% 
    left_join(intersections_grille, by = "id") %>% 
    group_by(year, month, type) %>% 
    mutate(weight = area / sum(area),
           value_weighted = value * weight) %>% 
    summarise(value = sum(value_weighted)) %>% 
    mutate(region = id_region)
}# Fin de cells_f()


cells <- list()
a_parcourir <- nz_df_regions$region %>% unique
pb <- txtProgressBar(min = 1, max = length(a_parcourir), style=3)
for(i in a_parcourir){
  cells[[i]] <- cells_f(i)
  setTxtProgressBar(pb, which(a_parcourir == i))
}


# Les donnees climatiques historiques pour chaque region, par jour
# cells_hist <- cells$climate_hist
cells_hist <- bind_rows(cells)

ggplot(data = 
         nz_df_regions %>% 
         left_join(cells_hist %>% 
                     filter(type %in% c("hist", "rcp85")) %>% 
                     filter(year %in% c(1986:2005, 2081:2100)) %>% 
                     group_by(region, type) %>% 
                     summarise(value = mean(value)) %>% 
                     spread(type, value) %>% 
                     mutate(difference = rcp85 - hist), by = "region"),
       aes(x = long, y = lat, group = group, fill = difference)) +
  geom_polygon() +
  scale_fill_gradient2(low = "red", mid = "white", high = "green") +
  coord_quickmap()

# Weights
library(readxl)
cultures <- read_excel("../economic_data/matrix_pond_agriculture.xls", sheet="RNA434201_20150707_091730_92", skip = 2)
colnames(cultures)[1] <- "year"
cultures <- cultures[-1,]
cultures <- cultures[, seq(1, which(colnames(cultures) == "New Zealand")-1)]
cultures <- cultures[seq(1, which(str_detect(cultures$year, "Table information:"))-1),]
cultures <- apply(cultures, 2, as.numeric) %>% data.frame() %>% tbl_df()
cultures <-
  cultures %>% 
  gather(region, gdp, -year) %>% 
  mutate(year = as.numeric(year))

cultures <- 
  cultures %>% 
  mutate(region = str_replace_all(region, "\\.", " "),
         region = ifelse(region == "Hawke s Bay", yes = "Hawke's Bay", no = region),
         region = ifelse(region == "Manawatu Wanganui", yes = "Manawatu-Wanganui", no = region),
         region = ifelse(region == "Tasman Nelson", yes = "Tasman/Nelson", no = region))

cultures_weights <- 
  cultures %>% 
  filter(region %in% cells_hist$region) %>% 
  group_by(year) %>% 
  mutate(weight = gdp / sum(gdp)) %>% 
  select(-gdp) %>% 
  mutate(region = as.character(region))

# Les parts sur la totalite de la periode
cultures_weights_all <- 
  cultures %>% 
  filter(region %in% cells_hist$region) %>% 
  group_by(region) %>% 
  summarise(gdp = mean(gdp)) %>% 
  mutate(weight_all = gdp / sum(gdp)) %>% 
  select(-gdp)

ggplot(data = 
         nz_df_regions %>% 
         left_join(cultures_weights_all, by = "region"),
       aes(x = long, y = lat, group = group, fill = weight_all)) +
  geom_polygon() +
  scale_fill_gradient(low = "yellow", high = "red") +
  coord_quickmap()



precipitations <-
  cells_hist %>% 
  filter(region %in% cultures_weights_all$region) %>% 
  left_join(cultures_weights) %>% 
  left_join(cultures_weights_all) %>% 
  # Si jamais le poids est absent: on prend le poids calcule sur la periode totale
  mutate(weight = ifelse(is.na(weight), yes = weight_all, no = weight),
         value = value * weight) %>% 
  select(-weight_all) %>% 
  group_by(year, month, type) %>% 
  summarise(rainfall = sum(value))


ggplot(data = precipitations %>% 
         mutate(years = year + month/12 - 1/12),
       aes(x = years, y = rainfall, colour = type)) +
  geom_line() +
  facet_wrap(~month)


ggplot(data = 
         cells_hist %>% 
         mutate(years = year + (month/12-1/12)) %>% 
         group_by(region, month) %>% 
         summarise(moy = mean(value)),
       aes(x = month, y = moy)) +
  geom_bar(stat="identity") +
  facet_wrap(~region)


ggplot(data = precipitations %>% 
         mutate(years = year + (month/12-1/12)) %>% 
         group_by(type, month) %>% 
         summarise(rainfall = mean(rainfall)),
       aes(x = month, y = rainfall, fill = type)) +
  geom_bar(stat="identity", position = "dodge")


precipitations <- 
  precipitations %>% 
  rename(value = rainfall)

# Statistiques de long terme pour chaque mois et chaque type (hist et RCPs)

df_lt <-
  precipitations %>%
  filter(year %in% c(1986:2005)) %>% 
  group_by(month) %>%
  summarise(value_mean = mean(value),
            value_med = median(value),
            value_min = min(value),
            value_max = max(value),
            value_sd = sd(value)) %>% 
  ungroup()

# Strandardize
precipitations_std <-
  precipitations %>%
  left_join(df_lt) %>%
  mutate(value_s = ifelse(value <= value_med,
                          yes = (value - value_med)/(value_med - value_min) * 100,
                          no = (value - value_med)/(value_max - value_med) * 100),
         value_demeaned = value - value_mean,
         value_pct = 100*(value - value_mean) / value_mean,
         value_norm = (value - value_mean) / value_sd)



# Index creation
# SMDI
# SD_{ij} = \frac{SW_{ij} - Med(SW_{j})}{Med(SW_{j})}, j = month, i = year
# Init:
# SMDI_{1} = SD_1 / 50
# Reason:
# SMDI_{j} = 0.5 * SMDI_{j-1} + \frac{SD_j}/50


# Help function to compute the index for a station or a region
# @x: type de donnees (hist, rcp26, rcp85)
# x <- unique(precipitations_std$type)[1]
calcul_smdi <- function(x){
  
  df_tmp <- 
    precipitations_std %>% 
    filter(type == x)
  
  index <- rep(NA, nrow(df_tmp))
  # Initialisation
  index[1] <- df_tmp$value_s[1]/(25*val_T + 25)
  # i <- 1
  for(i in 2:nrow(df_tmp)){
    index[i] <- df_tmp$value_s[i]/(25*val_T + 25)  - valeur_c(val_T)*index[i-1]
  }
  df_tmp$index <- index
  df_tmp
}# End of calcul_smdi()

val_T <- 1
valeur_c <- function(t) -25/(25*t+25)
precipitations_std <- lapply(unique(precipitations_std$type), calcul_smdi) %>% 
  bind_rows()


quarters <- 
  cbind(month = 1:12,
        quarter = rep(1:4, each = 3)) %>% 
  data.frame(stringsAsFactors = FALSE)

precipitations_std <- 
  precipitations_std %>% 
  left_join(quarters)

# Quarterly aggregation
precipitations_q <- 
  precipitations_std %>% 
  group_by(type, year, quarter) %>% 
  summarize(value = sum(value, na.rm = TRUE),
            index = mean(index, na.rm = TRUE),
            value_demeaned = mean(value_demeaned, na.rm = TRUE),
            value_pct = mean(value_pct, na.rm = TRUE),
            value_norm = mean(value_norm, na.rm = TRUE)) %>% 
  ungroup()


precipitations_q <- 
  precipitations_q %>% 
  mutate(years = year + quarter / 4 - 1/4)



ggplot(data = precipitations_q,
       aes(x = years, y = value_demeaned, colour = type)) +
  geom_line() +
  facet_wrap(~quarter)

precipitations_q %>% 
  group_by(type) %>% 
  summarise(moy = mean(value),
            sd = sd(value))


# Donnees historiques + rcp26
precipitations_q_26 <- 
  precipitations_q %>% 
  ungroup() %>% 
  filter(type %in% c("hist", "rcp26")) %>% 
  select(-type) %>% 
  arrange(years)

precipitations_q_45 <- 
  precipitations_q %>% 
  ungroup() %>% 
  filter(type %in% c("hist", "rcp45")) %>% 
  select(-type) %>% 
  arrange(years)

precipitations_q_60 <- 
  precipitations_q %>% 
  ungroup() %>% 
  filter(type %in% c("hist", "rcp60")) %>% 
  select(-type) %>% 
  arrange(years)

precipitations_q_85 <- 
  precipitations_q %>% 
  ungroup() %>% 
  filter(type %in% c("hist", "rcp85")) %>% 
  select(-type) %>% 
  arrange(years)

# CHOIX VARIABLE ICI #
precipitations_q_26 <- 
  precipitations_q_26 %>% 
  select(value) %>% 
  ts(start = c(precipitations_q_26$years[1]), frequency = 4)




precipitations_q_45 <- 
  precipitations_q_45 %>% 
  select(value) %>% 
  ts(start = c(precipitations_q_45$years[1]), frequency = 4)

precipitations_q_60 <- 
  precipitations_q_60 %>% 
  select(value) %>% 
  ts(start = c(precipitations_q_60$years[1]), frequency = 4)

precipitations_q_85 <- 
  precipitations_q_85 %>% 
  select(value) %>% 
  ts(start = c(precipitations_q_85$years[1]), frequency = 4)


# start_years_sample <- 1960 ; df <- precipitations_q_26
# @df : ts object
# @start_years_sample: start date for window
# @length_window: length of the window (in years)
#start_years_sample <- 1987.25
ar1_sd_residuals <- function(start_years_sample, df, length_window){
  end_years_sample <- start_years_sample+(0.25*4)*(length_window)
  data <- window(df,start=start_years_sample,end=end_years_sample)
  # dummies=forecast::seasonaldummy(data)
  #ar1 <- arima(x = data, xreg = dummies, order = c(1,0,0))
  ar1 <- arima(x = data, order = c(1,0,0))
  list(sd = sd(residuals(ar1)), coefs = coef(ar1))
}



seq(1989, 2014.25, by =.25) %>% length()/4
length_window <- 25.5
# length_window <- 28
# fenetres <- seq(1987.25, 2045.25, by = 0.25)
date_fin <- 2100

fenetres <- seq(1989.00, date_fin - length_window, by = 0.25)

cbind(debut = fenetres, fin = fenetres+(0.25*4)*(length_window))



process_rcp26 <- lapply(fenetres, ar1_sd_residuals,
                        df = precipitations_q_26,
                        length_window = length_window)
sd_rcp26 <- lapply(process_rcp26, function(x) x$sd) %>% unlist()
racine_rcp26 <- lapply(process_rcp26, function(x) x$coefs["ar1"]) %>% unlist()

process_rcp45 <- lapply(fenetres, ar1_sd_residuals,
                        df = precipitations_q_45,
                        length_window = length_window)
sd_rcp45 <- lapply(process_rcp45, function(x) x$sd) %>% unlist()
racine_rcp45 <- lapply(process_rcp45, function(x) x$coefs["ar1"]) %>% unlist()


process_rcp60 <- lapply(fenetres, ar1_sd_residuals,
                        df = precipitations_q_60,
                        length_window = length_window)
sd_rcp60 <- lapply(process_rcp60, function(x) x$sd) %>% unlist()
racine_rcp60 <- lapply(process_rcp60, function(x) x$coefs["ar1"]) %>% unlist()

process_rcp85 <- lapply(fenetres, ar1_sd_residuals,
                        df = precipitations_q_85,
                        length_window = length_window)
sd_rcp85 <- lapply(process_rcp85, function(x) x$sd) %>% unlist()
racine_rcp85 <- lapply(process_rcp85, function(x) x$coefs["ar1"]) %>% unlist()

ggplot(data = data.frame(racine = racine_rcp26, scenario = "2.6") %>% 
         mutate(id = row_number()) %>% 
         bind_rows(data.frame(racine = racine_rcp45, scenario = "4.5") %>% 
                     mutate(id = row_number())) %>% 
         bind_rows(data.frame(racine = racine_rcp60, scenario = "6.0") %>% 
                     mutate(id = row_number())) %>% 
         bind_rows(data.frame(racine = racine_rcp85, scenario = "8.5") %>% 
                     mutate(id = row_number())),
       aes(x = id, y = racine, colour = scenario)) +
  geom_line()

df_sd <- data.frame(rcp26 = sd_rcp26,
                    rcp45 = sd_rcp45,
                    rcp60 = sd_rcp60,
                    rcp85 = sd_rcp85,
                    start_sample = fenetres) %>% 
  tbl_df() %>% 
  mutate(end_sample = start_sample+(0.25*4)*(length_window-1),
         mid_sample = (start_sample+end_sample)/2) %>% 
  gather(scenario, value, rcp26, rcp45, rcp60, rcp85) %>% 
  mutate(scenario = as.character(scenario)) %>% 
  mutate(scenario = ifelse(end_sample < 2012, yes = "hist", no = scenario)) %>% 
  # Sans incidence ici
  group_by(start_sample, end_sample, mid_sample, scenario) %>% 
  summarise(value = mean(value)) %>% 
  ungroup() %>% 
  mutate(scenario = factor(scenario, levels = c("hist", "rcp26", "rcp45", "rcp60", "rcp85"),
                           labels = c("Historical", "RCP 26", "RCP 45", "RCP 60", "RCP 85")))


x_scale <- df_sd$end_sample %>% range()

ggplot(data = df_sd, aes(x = end_sample, y = value)) +
  geom_line(aes(colour = scenario)) +
  scale_colour_manual("", values = c("Historical" = "black", "RCP 26" = "#27377A", "RCP 45" = "#709FC8", "RCP 60" = "#DE632B", "RCP 85" = "#CD1020")) +
  #scale_linetype_manual("", values = c("Historical" = "solid", "RCP 26" = "dashed", "RCP 85" = "dashed")) +
  xlab("End Date of Rolling Window") +
  ylab("") +
  geom_smooth()


fit_rcp26 <- 
  df_sd %>% 
  filter(scenario %in% c("RCP 26", "Historical")) %>% 
  mutate(index = row_number())
fit_rcp26$fitted <- fitted(lm(data = fit_rcp26, value ~ index))

fit_rcp45 <- 
  df_sd %>% 
  filter(scenario %in% c("RCP 45", "Historical")) %>% 
  mutate(index = row_number())
fit_rcp45$fitted <- fitted(lm(data = fit_rcp45, value ~ index))

fit_rcp60 <- 
  df_sd %>% 
  filter(scenario %in% c("RCP 60", "Historical")) %>% 
  mutate(index = row_number())
fit_rcp60$fitted <- fitted(lm(data = fit_rcp60, value ~ index))

fit_rcp85 <- 
  df_sd %>% 
  filter(scenario %in% c("RCP 85", "Historical")) %>% 
  mutate(index = row_number())
fit_rcp85$fitted <- fitted(lm(data = fit_rcp85, value ~ index))




# Calcul du taux de croissance par OLS
# Les taux de croissance instantanee
croiss_instant_26 <- coef(lm(log(fitted)~ 1+index, data = fit_rcp26))[2]
croiss_instant_45 <- coef(lm(log(fitted)~ 1+index, data = fit_rcp45))[2]
croiss_instant_60 <- coef(lm(log(fitted)~ 1+index, data = fit_rcp60))[2]
croiss_instant_85 <- coef(lm(log(fitted)~ 1+index, data = fit_rcp85))[2]

croiss_compo_26 <- exp(croiss_instant_26)-1
croiss_compo_45 <- exp(croiss_instant_45)-1
croiss_compo_60 <- exp(croiss_instant_60)-1
croiss_compo_85 <- exp(croiss_instant_85)-1



croiss_compo_26*100
croiss_compo_45*100
croiss_compo_60*100
croiss_compo_85*100

# Les taux de croissance sur la periode totale
tx_croissance_tot <- list(rcp26 = ((1+croiss_compo_26)^nrow(fit_rcp26) - 1) * 100,
                          rcp45 = ((1+croiss_compo_45)^nrow(fit_rcp45) - 1) * 100,
                          rcp60 = ((1+croiss_compo_60)^nrow(fit_rcp60) - 1) * 100,
                          rcp85 = ((1+croiss_compo_85)^nrow(fit_rcp85) - 1) * 100)







source("../../variables_names.R")


fit_rcp26$loess <- predict(loess(value~index, data = fit_rcp26))
fit_rcp45$loess <- predict(loess(value~index, data = fit_rcp45))
fit_rcp60$loess <- predict(loess(value~index, data = fit_rcp60))
fit_rcp85$loess <- predict(loess(value~index, data = fit_rcp85))


p <- ggplot(data = df_sd %>% 
              mutate(scenario = as.character(scenario)) %>% 
              mutate(scenario = ifelse(scenario == "RCP 26", yes = "RCP 2.6", no = scenario),
                     scenario = ifelse(scenario == "RCP 45", yes = "RCP 4.5", no = scenario),
                     scenario = ifelse(scenario == "RCP 60", yes = "RCP 6.0", no = scenario),
                     scenario = ifelse(scenario == "RCP 85", yes = "RCP 8.5", no = scenario)
              ),
            aes(x = end_sample, y = value)) +
  geom_line(aes(colour = scenario, linetype = scenario), size = 2.5) +
  scale_colour_manual("", values = c("Historical" = "black",
                                     "RCP 2.6" = "#27377A", 
                                     "RCP 4.5" = "#709FC8", 
                                     "RCP 6.0" = "#DE632B", 
                                     "RCP 8.5" = "#CD1020")) +
  #guide = guide_legend(override.aes = list(size = 2))) +
  scale_linetype_manual("", values = c("Historical" = "solid",
                                       "RCP 2.6" = "solid", 
                                       "RCP 4.5" = "dashed", 
                                       "RCP 6.0" = "dotted", 
                                       "RCP 8.5" = "dotdash")) +
  #scale_linetype_manual("", values = c("Historical" = "solid", "RCP 26" = "dashed", "RCP 85" = "dashed")) +
  xlab("End Date of Rolling Window") +
  # geom_line(data = fit_rcp26, aes(x = end_sample, y = loess),
  #           colour = "#27377A", linetype = "dotted", size = 2.5) +
  #   geom_line(data = fit_rcp45, aes(x = end_sample, y = loess),
  #             colour = "#709FC8", linetype = "dotted", size = 2.5) +
  #   geom_line(data = fit_rcp60, aes(x = end_sample, y = loess),
  #             colour = "#DE632B", linetype = "dotted", size = 2.5) +
  # geom_line(data = fit_rcp85, aes(x = end_sample, y = loess),
  #           colour = "#CD1020", linetype = "dotted", size = 2.5) +
  ylab("") +
  scale_x_continuous(limits = x_scale, breaks = seq(floor(x_scale[1] / 5) * 5,
                                                    x_scale[length(x_scale)], by = 10)) +
  theme_paper() +
  theme(axis.title = element_text(),
        legend.key = element_rect(fill = NA),
        legend.key.size = unit(2, "lines"),
        legend.key.width = unit(3, "lines"),
        legend.direction = "horizontal")

p

# width <- 15
# ggsave(p, file = "../../../images/sd_ar1_rainfall.pdf", width = width, height = .5*width)


#source("../../export_tex.R")
library(plotRTeX)
width <- 15

if(afficher_graph){
  ggplot2_to_pdf(plot = p, path = "../../../images/",
                 filename = "sd_ar1_rainfall",
                 width = width, height = .5*width)
  
  width <- 8
  ggplot2_to_pdf(plot = p, path = "../../../images/",
                 filename = "rcp_scenarios_rainfall",
                 width = width, height = width)
  
  
  
}


library(readr)
write_delim(df_sd, path = "sd_ar1_rainfall.csv", delim = ";")


unlist(tx_croissance_tot)

# 
# rcp26.index rcp45.index rcp60.index rcp85.index 
# -4.095090    6.820885    9.294213   23.249574


lapply(tx_croissance_tot, function(x) 1+x/100) %>% unlist()





list(croiss_instant_26 = as.numeric(croiss_instant_26),
     croiss_instant_45 = as.numeric(croiss_instant_45),
     croiss_instant_60 = as.numeric(croiss_instant_60),
     croiss_instant_85 = as.numeric(croiss_instant_85),
     croiss_compo_26 = as.numeric(croiss_compo_26),
     croiss_compo_45 = as.numeric(croiss_compo_45),
     croiss_compo_60 = as.numeric(croiss_compo_60),
     croiss_compo_85 = as.numeric(croiss_compo_85),
     nb_periodes = nrow(fit_rcp26),
     debut = fit_rcp26$start_sample[1])


# $croiss_instant_26
# [1] -0.0001271971
# 
# $croiss_instant_45
# [1] 0.0001896974
# 
# $croiss_instant_60
# [1] 0.0002581098
# 
# $croiss_instant_85
# [1] 0.0006174317
# 
# $croiss_compo_26
# [1] -0.000127189
# 
# $croiss_compo_45
# [1] 0.0001897154
# 
# $croiss_compo_60
# [1] 0.0002581432
# 
# $croiss_compo_85
# [1] 0.0006176223
# 
# $nb_periodes
# [1] 343
# 
# $debut
# [1] 1989


c(croiss_compo_26 = as.numeric(croiss_compo_26),
  croiss_compo_45 = as.numeric(croiss_compo_45),
  croiss_compo_60 = as.numeric(croiss_compo_60),
  croiss_compo_85 = as.numeric(croiss_compo_85)) * 10^3


# croiss_compo_26 croiss_compo_45 croiss_compo_60 croiss_compo_85 
# -0.1218964       0.1923896       0.2591393       0.6096352 


ecarts_types <- 
  data.frame(year = c(x_scale[1], x_scale[2]),
             sd = c(100, 100+tx_croissance_tot$rcp26),
             scenario = "RCP 2.6") %>% 
  bind_rows(
    data.frame(year = c(x_scale[1], x_scale[2]),
               sd = c(100, 100+tx_croissance_tot$rcp45),
               scenario = "RCP 4.5")
  ) %>% 
  bind_rows(
    data.frame(year = c(x_scale[1], x_scale[2]),
               sd = c(100, 100+tx_croissance_tot$rcp60),
               scenario = "RCP 6.0")
  ) %>% 
  bind_rows(
    data.frame(year = c(x_scale[1], x_scale[2]),
               sd = c(100, 100+tx_croissance_tot$rcp85),
               scenario = "RCP 8.5")
  )


p_ecarts_types <-
  ggplot(data = ecarts_types, aes(x = year, y = sd, colour = scenario)) +
  geom_line(size = 2.5) +
  scale_colour_manual("", values = c("Historical" = "black",
                                     "RCP 2.6" = "#27377A", 
                                     "RCP 4.5" = "#709FC8", 
                                     "RCP 6.0" = "#DE632B", 
                                     "RCP 8.5" = "#CD1020")) +
  scale_linetype_manual("", values = c("Historical" = "solid",
                                       "RCP 2.6" = "solid", 
                                       "RCP 4.5" = "dashed", 
                                       "RCP 6.0" = "dotted", 
                                       "RCP 8.5" = "dotdash")) +
  ylab(NULL) + xlab(NULL) +
  scale_x_continuous(limits = x_scale, breaks = seq(floor(x_scale[1] / 5) * 5,
                                                    x_scale[length(x_scale)], by = 10)) +
  theme_paper() +
  theme(axis.title = element_text(),
        legend.key = element_rect(fill = NA),
        legend.key.size = unit(2, "lines"),
        legend.key.width = unit(3, "lines"),
        legend.direction = "horizontal")



width <- 8

if(afficher_graph)
  ggplot2_to_pdf(plot = p_ecarts_types, path = "../../../images/",
                 filename = "rcp_scenarios_sd",
                 width = width, height = width)

save(ecarts_types, file = "rcp_scenarios_sd.rda")
rcp_sd <- 
  df_sd %>% 
  mutate(scenario = as.character(scenario)) %>% 
  mutate(scenario = ifelse(scenario == "RCP 26", yes = "RCP 2.6", no = scenario),
         scenario = ifelse(scenario == "RCP 45", yes = "RCP 4.5", no = scenario),
         scenario = ifelse(scenario == "RCP 60", yes = "RCP 6.0", no = scenario),
         scenario = ifelse(scenario == "RCP 85", yes = "RCP 8.5", no = scenario)
  )

save(rcp_sd, file = "rcp_scenarios_rainfall.rda")
