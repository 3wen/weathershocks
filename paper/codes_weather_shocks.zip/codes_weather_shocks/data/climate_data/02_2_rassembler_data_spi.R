library(dplyr)
library(stringr)
library(lubridate)
library(readr)
library(ggplot2)
library(readxl)
library(tidyr)
library(gpclib)
library(geoR)

save_graphs <- FALSE

# If not already executed, this script needs to be run
# source("02_1_rassembler_help.R")

# The following function is used afterwards to create an index of drought
# It is from the following paper:
# Narasimhan, B., & Srinivasan, R. (2005). 
# Development and evaluation of Soil Moisture Deficit Index (SMDI) 
# and Evapotranspiration Deficit Index (ETDI) for agricultural drought monitoring.
# Agricultural and Forest Meteorology, 133(1), 69-88.
val_T <- 1
valeur_c <- function(t) -25/(25*t+25)


# code_variable <- "66" ; station_unique = FALSE ; num_station = NULL ; stations_mean = FALSE
climate_variables <- function(code_variable, station_unique = FALSE, 
                              num_station = NULL, stations_mean = FALSE, val_T=1){
  # Recuperer les donnees
  df <- mise_en_forme_mesure(code_variable)
  # Retirer les observations des stations qui sont trop proches des cotes
  df <- df %>% filter(!is.na(region))
  
  # Effectuer les statistiques par region, en moyennant les valeurs des stations d'abord
  # Moyenne par region, annee et mois
  df <-
    df %>% 
    group_by(variable, region, weight, year, quarter, month) %>% 
    summarize(value = mean(value, na.rm = TRUE)) %>% 
    ungroup() %>% 
    arrange(year, month)
  
  # Long term statistics for each region
  df_lt <- 
    df %>% 
    group_by(variable, region, month) %>% 
    summarise(value_mean = mean(value),
              value_med = median(value),
              value_min = min(value),
              value_max = max(value),
              value_sd = sd(value))
  
  # Strandardize
  df <- 
    df %>% 
    left_join(df_lt) %>% 
    mutate(value_s = ifelse(value <= value_med,
                            yes = (value - value_med)/(value_med - value_min) * 100,
                            no = (value - value_med)/(value_max - value_med) * 100),
           value_demeaned = value / value_mean,
           value_pct = 100*(value - value_mean) / value_mean,
           value_norm = (value - value_mean) / value_sd)
  
  # Index creation
  # SMDI
  # SD_{ij} = \frac{SW_{ij} - Med(SW_{j})}{Med(SW_{j})}, j = month, i = year
  # Init:
  # SMDI_{1} = SD_1 / 50
  # Reason:
  # SMDI_{j} = 0.5 * SMDI_{j-1} + \frac{SD_j}/50
  
  # Help function to compute the index for a station or a region
  # @x: a station id if stations_mean, a region id otherwise
  # x <- unique(df$region)[1]
  calcul_smdi <- function(x){
    
    if(stations_mean){
      df_tmp <- 
        df %>% 
        filter(agent == x)
    }else{
      df_tmp <- 
        df %>% 
        filter(region == x)
    }
    
    index <- rep(NA, nrow(df_tmp))
    # Initialisation
    index[1] <- df_tmp$value_s[1]/(25*val_T + 25)
    # i <- 1
    for(i in 2:nrow(df_tmp)){
      index[i] <- df_tmp$value_s[i]/(25*val_T + 25)  - valeur_c(val_T)*index[i-1]
    }
    df_tmp$index <- index
    df_tmp
  }# End of calcul_smdi()
  
  if(stations_mean){
    df <- lapply(unique(df$agent), calcul_smdi) %>% 
      bind_rows()
  }else{
    df <- lapply(unique(df$region), calcul_smdi) %>% 
      bind_rows()
  }# End else
  
  # Removing data where no weight is available
  df <- df %>% filter(!is.na(weight))
  
  
  
  # SPI index for each region
  calcul_spi <- function(x){
    if(stations_mean){
      df_tmp <- 
        df %>% 
        filter(agent == x)
    }else{
      df_tmp <- 
        df %>% 
        filter(region == x)
    }
    
    min_year <- min(df_tmp$year)
    max_year <- max(df_tmp$year)
    df_tmp <- 
      df_tmp %>% 
      select(year, month, value) %>% 
      spread(year, value) %>% 
      rename(Months = month)
    
    write.table(df_tmp,file="df_tmp_spi.txt",quote=FALSE,row.names=TRUE)
    df_tmp_spi <- spi::spi(3,"df_tmp_spi.txt",min_year,max_year, output = 1, title="nz")
    
    df_tmp_spi <- 
      df_tmp_spi %>% 
      gather(month, spi, -dates) %>% 
      rename(year = dates) %>% 
      mutate(month = str_sub(month, 2)) %>% 
      mutate(month = month.abb[as.numeric(month)])
    # mutate(YEARS = as.numeric(year) + (as.numeric(month)-1)/12)
    
    if(stations_mean){
      df_tmp_spi <- 
        df_tmp_spi %>% 
        mutate(agent = x)
    }else{
      df_tmp_spi <- 
        df_tmp_spi %>% 
        mutate(region = x)
    }
    
    df_tmp_spi
  }# Fin de calcul_spi
  
  
  if(stations_mean){
    df_smpi <- lapply(unique(df$agent), calcul_spi) %>% 
      bind_rows() %>% 
      tbl_df()
  }else{
    df_smpi <- lapply(unique(df$region), calcul_spi) %>% 
      bind_rows() %>% 
      tbl_df()
  }# End else
  
  df <- 
    df %>% 
    left_join(df_smpi)
  
  # Weighted values
  df <- 
    df %>% 
    ungroup() %>% 
    mutate(value = value * weight,
           value_spi = spi * weight,
           index = index * weight,
           value_demeaned = value_demeaned * weight,
           value_pct = value_pct * weight,
           value_norm = value_norm * weight) %>% 
    group_by(variable, year, quarter, month) %>% 
    summarize(value = sum(value),
              spi = sum(value_spi),
              index = sum(index),
              value_demeaned = sum(value_demeaned),
              value_pct = sum(value_pct),
              value_norm = sum(value_norm)) %>% 
    ungroup()
  
  
  df
}# End of climate_variables()


# Soil Moisture
df_sm <- climate_variables("66")
# Rainfall
df_rainfall <- climate_variables("00")

# Gathering different climatic variables in a single data.frame
df_meteo_month <- 
  df_sm %>% 
  bind_rows(df_rainfall) %>% 
  left_join(codes)


# Quarterly aggregation
df_meteo <- 
  df_meteo_month %>% 
  group_by(variable, year, quarter) %>% 
  summarize(value = mean(value, na.rm = TRUE),
            spi = mean(spi, na.rm = TRUE),
            index = mean(index, na.rm = TRUE),
            value_demeaned = mean(value_demeaned, na.rm = TRUE),
            value_pct = mean(value_pct, na.rm = TRUE),
            value_norm = mean(value_norm, na.rm = TRUE))

# df_rainfall_w <- 
#   df_rainfall_w %>% 
#   left_join(data.frame(month = month.abb, mois = 1:12)) %>% 
#   mutate(YEARS = as.numeric(year) + (as.numeric(mois)-1)/12)


# ggplot(data = df_rainfall_w %>% 
#          group_by(variable, year, quarter) %>% 
#          summarise(spi = mean(spi)) %>% 
#          ungroup() %>% 
#          mutate(YEARS = as.numeric(year) + (as.numeric(quarter)-1)/4),
#        aes(x = YEARS, y = spi)) +
#   geom_line() +
#   geom_vline(xintercept = c(2008, 1998, 2013), linetype = "dotted", col = "red") +
#   annotate(geom = "rect", xmin = 2013, xmax = 2013+(2/12), ymin = -Inf, ymax = Inf,
#            alpha = .2, fill = "dodger blue")


# EXPORT RESULTS #
# ============== #

meteo <- 
  df_meteo %>% 
  mutate(value = round(value, 4),
         index = round(index, 4),
         spi = round(spi, 4),
         valuedemeaned = round(value_demeaned, 4),
         valuepct = round(value_pct, 4),
         valuenorm = round(value_norm, 4)) %>% 
  select(-value_demeaned, -value_pct, -value_norm) %>% 
  unite(val_ind, value, index, spi, valuedemeaned, valuepct, valuenorm, sep = "_") %>% 
  spread(variable, val_ind) %>% 
  gather(variable, val_ind, -year, -quarter) %>% 
  separate(val_ind, c("value", "index", "spi", "valuedemeaned", "valuepct", "valuenorm"), sep = "_") %>% 
  gather(type, value, value, index, spi, valuedemeaned, valuepct, valuenorm) %>% 
  mutate(date = year + as.numeric(as.character(quarter))/4 - 0.25,
         value = as.numeric(value)) %>% 
  unite(var, variable, type, sep = "_") %>% 
  spread(var, value) %>% 
  rename(YEARS = date,
         rain_val = rainfall_valuedemeaned,
         soil_moist = sm_mean_valuedemeaned,
         soil_moist_norm = sm_mean_valuenorm,
         crfi = rainfall_index,
         smdi = sm_mean_index,
         spi = rainfall_spi
  ) %>% 
  select(-sm_mean_spi)


save(meteo, file = "meteo.rda")

