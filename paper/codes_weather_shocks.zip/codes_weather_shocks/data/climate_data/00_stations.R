# Get stations of interest
library(readr)
library(dplyr)
library(lubridate)
library(stringr)


#n <- N[1]
importer_station <- function(n){
  
  df <- read.csv(n, skip=6, sep = "\t")
  df <- df[-which(str_detect(df$Agent, "Numbe")),]
  df <- tbl_df(df)
  
  df <- 
    df %>% 
    rename(agent = Agent,
           network = Network,
           start_date = Start_Date,
           end_date = End_Date,
           pct_complete = Percent_Complete,
           name = Name,
           lat = `Lat.dec_deg.`,
           long = `Long.dec_deg.`)
  
  df <- 
    df %>% 
    mutate(start_date = dmy(start_date, locale = "en_us"),
           end_date = dmy(end_date, locale = "en_us"))
}# End of (importer_station)

# From the folder name (`dossier`), returns the data of the variable of interest
# that is mentioned by the folder name, as a table (`data.frame`)
# @dossier (string) : nom de dossier
# dossier <- "stations_66"
stations_to_df <- function(dossier){
  N <- list.files(dossier, full.names = TRUE)
  stations <- lapply(N, importer_station)
  stations <- bind_rows(stations)
  stations <- unique(stations)
  
  # Remove stations that closed prior to 1980
  stations <- 
    stations %>% 
    filter(year(end_date) >= 1980)
  save(stations, file = str_c(dossier, ".rda"))
  
  stations
}# Fin de stations_to_df()

# 00	MTHLY: TOTAL RAIN	Mthly_Stats: Total Rainfall
# 02	MTHLY: MEAN TEMP	Mthly_Stats: Mean Air Temperature; 0.5* (Max + Min)
# 66 	MTHLY: MEAN DEFICIT (WBAL) 	Mthly_Stats: Mean Deficit Of Soil Moisture (Wbal Awc=150mm)
# 69	MTHLY: MEAN SOIL MOISTURE %	Mthly_Stats: Mean Soil Moisture Percent At 20cm Depth
# 74 	MTHLY: DAYS OF DEFICIT (WBAL) 	Mthly_Stats: Days Of Deficit (Wbal Awc=150mm)
codes <- data.frame(code = c("00", "02", "66", "69", "74"),
                    variable = c("rainfall", "temperature", "sm_mean", "sm_pct", "sm_def_days"))

# Total Rainfall
stations_00 <- stations_to_df("stations_00")
# Mean Temperature
stations_02 <- stations_to_df("stations_02")
# Mean Deficit Of Soil Moisture
stations_66 <- stations_to_df("stations_66")
# Mean Soil Moisture Percent
stations_69 <- stations_to_df("stations_69") # No need to get this one, actually
# Days Of Deficit
stations_74 <- stations_to_df("stations_74")

stations_all <- list(stations_00 = stations_00,
                     stations_02 = stations_02,
                     stations_66 = stations_66,
                     stations_69 = stations_69,
                     stations_74 = stations_74)

save(stations_all, file = "stations_all.rda")


# annee <- 2015 ; stations <-  "stations_02"
# @annee (int)
# @stations (string) : name of station df
stations_annee <- function(annee, stations){
  stations <- get(stations)
  stations %>% 
    filter(annee >= year(start_date), annee <= year(end_date)) %>% 
    .$agent %>% 
    unique()
}


# stations_annee(1980, "stations_00")[1:100] %>% length() * 12


source("01_recuperer_data.R")

lien <- "http://cliflo.niwa.co.nz/pls/niwp/wa.logindb"
curl = getCurlHandle()
curlSetOpt(cookiejar="cookies.txt",  useragent = "Mozilla/5.0", followlocation = TRUE, curl=curl)
login <- postForm(uri = lien, .opts = curlOptions(followlocation=TRUE), curl = curl,
                  cusername="",# put your username here
                  cpwd="", # put your password here
                  submit="login",
                  ispopup="false",
                  ispopup="false")

# From the results obtained from the sent request
# returns the information as a tbl_df
mettre_en_forme_res <- function(df_tmp){
  df_tmp <- str_split(df_tmp, "\n")[[1]]
  
  if(any(str_detect(df_tmp, "No rows\\? See this help link"))){
    # Nothing to return
    res <- NULL
  }else{
    ind_deb <- which(str_detect(df_tmp, "^Station,Mon-YYYY"))
    ind_fin <- which(str_detect(df_tmp, "^UserName is = "))-2
    df_tmp <- df_tmp[ind_deb:ind_fin]
    df_tmp <- str_replace(df_tmp, "\r$", "")
    
    noms_variables <- str_split(df_tmp[1], ",")[[1]]
    
    head(do.call("rbind", str_split(df_tmp[-1], ",")))
    
    res <- do.call("rbind", str_split(df_tmp[-1], ",")) %>% 
      data.frame() %>% 
      tbl_df() %>% 
      select(-X6)
    colnames(res) <- noms_variables[-6]
  }# End else
  
  res
}# End of mettre_en_forme_res()


split_max_groupsize <- function(x, n) split(x, gl(ceiling(length(x)/n), n, length(x)))

# Obtain data for the stations, for a specific year
# @annee (int) year
# @stations (string) : name of station df
# annee <- 1980 ; stations <- "stations_00"
recup_annee <- function(annee, stations){
  stations_name <- stations
  stations <- get(stations_name)
  prm1 <- str_split(stations_name, "_")[[1]][2]
  stations_cour <- stations_annee(annee, stations_name)
  a_parcourir <- split_max_groupsize(stations_cour, 50)
  # i <- 1
  for(i in 1:length(a_parcourir)){
    df_tmp <- data_stations(stations = a_parcourir[[i]], annee = annee, prm1 = prm1)
    if(!dir.exists(str_c("data_", prm1))) dir.create(str_c("data_", prm1))
    if(!dir.exists(str_c("data_", prm1, "/raw"))) dir.create(str_c("data_", prm1, "/raw"))
    
    save(df_tmp, file = str_c("data_", prm1, "/raw/", annee, "_", sprintf("%02s", i), ".rda"))
    res <- mettre_en_forme_res(df_tmp)
    save(res, file = str_c("data_", prm1, "/", annee, "_", sprintf("%02s", i), ".rda"))
    rm(df_tmp, res)
  }
}# End of recup_annee()

# stations_cour <- stations_annee(2010)
# a_parcourir <- split_max_groupsize(stations_cour, 20)
# cat(a_parcourir[[5]], sep = ",")

#for(a in 2013:2015) recup_annee(a, "stations_00")
#for(a in 1980:2015) recup_annee(a, "stations_02")
for(a in 1987:2015) recup_annee(a, "stations_66")
for(a in 1980:2015) recup_annee(a, "stations_74")

