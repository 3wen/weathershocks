# This files imports raw climatic measures from whether stations into R.

# Get stations of interest
library(tidyverse)
library(lubridate)

#' importer_station
#' Imports weather data from a CSV file
#' @param n complete path to the CSV file to load
#n <- N[1]
importer_station <- function(n){
  
  df <- read.csv(n, skip=6, sep = "\t")
  df <- df[-which(str_detect(df$Agent, "Numbe")),]
  df <- tbl_df(df)
  
  df <- 
    df %>% 
    rename(agent = Agent,
           network = Network,
           start_date = Start_Date,
           end_date = End_Date,
           pct_complete = Percent_Complete,
           name = Name,
           lat = `Lat.dec_deg.`,
           long = `Long.dec_deg.`)
  
  df <- 
    df %>% 
    mutate(start_date = dmy(start_date, locale = "en_us"),
           end_date = dmy(end_date, locale = "en_us"))
}# End of importer_station()

#' stations_to_df
#' From the folder name, returns stations concerned by the climatic measure
#' The result is a data.frame
#' @param dossier (string) : folder name
#' dossier <- "stations_66"
stations_to_df <- function(dossier){
  N <- list.files(dossier, full.names = TRUE)
  stations <- lapply(N, importer_station)
  stations <- bind_rows(stations)
  stations <- unique(stations)
  
  # Remove stations that were closed before 1980
  stations <- 
    stations %>% 
    filter(year(end_date) >= 1980)
  save(stations, file = str_c(dossier, ".rda"))
  
  stations
}# Fin de stations_to_df()

# 00	MTHLY: TOTAL RAIN	Mthly_Stats: Total Rainfall
# 66 	MTHLY: MEAN DEFICIT (WBAL) 	Mthly_Stats: Mean Deficit Of Soil Moisture (Wbal Awc=150mm)
codes <- data.frame(code = c("00", "66"),
                    variable = c("rainfall", "sm_mean"))

# Total Rainfall
stations_00 <- stations_to_df("stations_00")
# Mean Deficit Of Soil Moisture
stations_66 <- stations_to_df("stations_66")

stations_all <- list(stations_00 = stations_00,
                     stations_66 = stations_66)


save(stations_all, file = "stations_all.rda")
load("stations_all.rda")

stations_00 <- stations_all$stations_00
stations_66 <- stations_all$stations_66

#' stations_annee
#' extract data for a list of stations for a given year
#' annee <- 2016 ; stations <-  "stations_00"
#' @param annee (int) year
#' @param stations (string) : name of station df
stations_annee <- function(annee, stations){
  stations <- get(stations)
  stations %>% 
    filter(annee >= year(start_date), annee <= year(end_date)) %>% 
    .$agent %>% 
    unique()
}# End of stations_annee()


# stations_annee(1980, "stations_00")[1:100] %>% length() * 12


source("01_1_recuperer_data.R")

# A (free) account is needed to download the data
lien <- "https://cliflo.niwa.co.nz/pls/niwp/wa.logindb"

# Login ID and password from http://cliflo.niwa.co.nz/
user_name <- "" # Set your own username here
password <- "" # Set your password here

curl = getCurlHandle()
curlSetOpt(cookiejar="cookies.txt",  useragent = "Mozilla/5.0", followlocation = TRUE, curl=curl)
login <- postForm(uri = lien, .opts = curlOptions(followlocation=TRUE), curl = curl,
                  cusername=user_name,
                  cpwd=password,
                  submit="login",
                  ispopup="false",
                  ispopup="false")

#' mettre_en_forme_res
#' Tidy the scraped data
#' From the result obtained after a POST request
#' Returns information recieved as a tbl_df
#' @param df_tmp
mettre_en_forme_res <- function(df_tmp){
  df_tmp <- str_split(df_tmp, "\n")[[1]]
  
  if(any(str_detect(df_tmp, "No rows\\? See this help link"))){
    # Nothing to return
    res <- NULL
  }else{
    ind_deb <- which(str_detect(df_tmp, "^Station,Mon-YYYY"))
    ind_fin <- which(str_detect(df_tmp, "^UserName is = "))-2
    df_tmp <- df_tmp[ind_deb:ind_fin]
    df_tmp <- str_replace(df_tmp, "\r$", "")
    
    noms_variables <- str_split(df_tmp[1], ",")[[1]]
    
    head(do.call("rbind", str_split(df_tmp[-1], ",")))
    
    res <- do.call("rbind", str_split(df_tmp[-1], ",")) %>% 
      data.frame() %>% 
      tbl_df() %>% 
      select(-X6)
    colnames(res) <- noms_variables[-6]
  }# End else
  
  res
}# End of mettre_en_forme_res()


split_max_groupsize <- function(x, n) split(x, gl(ceiling(length(x)/n), n, length(x)))

#' recup_annee
#' Scrape the data from niwa
#' @param annee (int) year
#' @param stations (string) : name of station df
#' annee <- 2016 ; stations <- "stations_00"
recup_annee <- function(annee, stations){
  stations_name <- stations
  stations <- get(stations_name)
  prm1 <- str_split(stations_name, "_")[[1]][2]
  stations_cour <- stations_annee(annee, stations_name)
  a_parcourir <- split_max_groupsize(stations_cour, 50)
  # i <- 1
  for(i in 1:length(a_parcourir)){
    df_tmp <- data_stations(stations = a_parcourir[[i]], annee = annee, prm1 = prm1)
    if(!dir.exists(str_c("data_", prm1))) dir.create(str_c("data_", prm1))
    if(!dir.exists(str_c("data_", prm1, "/raw"))) dir.create(str_c("data_", prm1, "/raw"))
    
    save(df_tmp, file = str_c("data_", prm1, "/raw/", annee, "_", sprintf("%02s", i), ".rda"))
    res <- mettre_en_forme_res(df_tmp)
    save(res, file = str_c("data_", prm1, "/", annee, "_", sprintf("%02s", i), ".rda"))
    rm(df_tmp, res)
  }
}# End of recup_annee()



for(a in 1980:2015) recup_annee(a, "stations_00")
for(a in 1980:2015) recup_annee(a, "stations_66")

for(a in 2014:2017) recup_annee(a, "stations_66")
for(a in 2014:2017) recup_annee(a, "stations_00")