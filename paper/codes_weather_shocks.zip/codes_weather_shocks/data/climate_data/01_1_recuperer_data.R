# Help function to download data from The National Climate Database


library(stringr)
library(RCurl)
library(httr)

# Sends a form to the Clifo Climate Database to retrieve data
# given station ids and years
# @stations: character vector of stations id
# @annee: year for which we want to download data
# @prm1: code of the variable (see in 00_stations.R for codes)
# stations <- c("18468", "15876") ; annee <- 1980
data_stations <- function(stations, annee, prm1){
  lien_requete <- "https://cliflo.niwa.co.nz/pls/niwp/wgenf.genform1_proc"
  
  p_stations <- str_c(stations, collapse=",")
  postForm(uri = lien_requete, .opts = curlOptions(followlocation=FALSE, verbose = TRUE), curl = curl,
           cselect = "wgenf.genform1?fset=defdtype",
           prm1 = prm1,
           dt1 = "ms,1",
           auswahl = "wgenf.genform1?fset=defagent",
           agents = p_stations,
           dateauswahl = "wgenf.genform1?fset=defdate",
           date1_1 = annee,
           date1_2 = "12",
           date1_3 = "15",
           date1_4 = "00",
           date2_1 = annee,
           date2_2 = "12",
           date2_3 = "16",
           date2_4 = "00",
           formatselection = "wgenf.genform1?fset=deffmt",
           TSselection = "UTC",
           dateformat = "0",
           Splitdate = "N",
           mimeselection = "csvplain",
           cstn_id = "A",
           cdata_order = "DSC",
           submit_sq = "Send+Query")
}# End of data_stations()