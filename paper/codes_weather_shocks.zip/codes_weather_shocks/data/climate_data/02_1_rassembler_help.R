# This file first identify the region associated with each station from its (lon,lat) coordinates.
# Then, it associates a weight to give to each region each year according to the share of agricultural GDP.


library(dplyr)
library(stringr)
library(lubridate)
library(readr)
library(ggplot2)
library(readxl)
library(tidyr)
library(gpclib)
library(geoR)


save_graphs <- FALSE

# 00	MTHLY: TOTAL RAIN	Mthly_Stats: Total Rainfall
# 66 	MTHLY: MEAN DEFICIT (WBAL) 	Mthly_Stats: Mean Deficit Of Soil Moisture (Wbal Awc=150mm)
codes <- data.frame(code = c("00", "66"),
                    variable = c("rainfall", "sm_mean"))


load("stations_all.rda")
stations <- stations_all %>% 
  bind_rows() %>% 
  select(agent, long, lat) %>% 
  unique()


# Map
load("../map/nz_df_regions.rda")

#ggplot(data = nz_df_regions, aes(x = long, y = lat, group = group)) + geom_polygon() + coord_quickmap()
head(nz_df_regions)

#' region_df_to_poly
#' Transforms each region from nz_df_regions to a gpc.poly object
#' @param r (string) : region name in df_regions
#' r <- unique(nz_df_regions$region)[1]
region_df_to_poly <- function(r){
  df_regions <- 
    nz_df_regions %>% 
    filter(region == r)
  
  polys <- df_regions %>% 
    group_by(group) %>% 
    do(pol = data.frame(x = .$long, y = .$lat) %>% as("gpc.poly")) %>% 
    .$pol
  
  # Now let us take the union of these polygons
  polyg <- polys[[1]]
  if(length(polys) > 1){
    for(i in 2:length(polys)){
      polyg <- gpclib::union(polyg, polys[[i]])
    }
  }
  polyg
}# End of region_df_to_poly()

# Regions in polygons
nz_df_regions_pol <- 
  lapply(unique(nz_df_regions$region), region_df_to_poly)

names(nz_df_regions_pol) <- unique(nz_df_regions$region)



library(surveillance)

#' stations_dans_region
#' For the region of index i in nz_df_regions_pol
#' returns a data frame of stations that are in that region
#' The data frame contains two columns: the station's id and the region name
#' @param i (int) indice dans nz_df_regions_pol
stations_dans_region <- function(i){
  inside <- 
    inside.gpc.poly(x = stations$long,
                    y = stations$lat,
                    nz_df_regions_pol[[i]],
                    mode.checked = FALSE)
  stations[which(inside), "agent"] %>% 
    mutate(region = unique(nz_df_regions$region)[i])
  
}# End of stations_dans_region()

stations_regions <-
  lapply(1:length(nz_df_regions_pol), stations_dans_region) %>% 
  bind_rows()

duplicated(stations_regions$agent) %>% any()

stations <- 
  stations %>% 
  left_join(stations_regions)


# We want to put weights on each region according to the share of agricultural GDP for each year
# This part is actually not used, as we redefine it below
cultures <- read_excel("../economic_data/matrix_pond_agriculture.xls", sheet="RNA434201_20150707_091730_92", skip = 2)
colnames(cultures)[1] <- "year"
cultures <- cultures[-1,]
cultures <- cultures[, seq(1, which(colnames(cultures) == "New Zealand")-1)]
cultures <- cultures[seq(1, which(str_detect(cultures$year, "Table information:"))-1),]
cultures <- apply(cultures, 2, as.numeric) %>% data.frame() %>% tbl_df()
cultures <-
  cultures %>% 
  gather(region, gdp, -year) %>% 
  mutate(year = as.numeric(year))

cultures <- 
  cultures %>% 
  mutate(region = str_replace_all(region, "\\.", " "),
         region = ifelse(region == "Hawke s Bay", yes = "Hawke's Bay", no = region),
         region = ifelse(region == "Manawatu Wanganui", yes = "Manawatu-Wanganui", no = region),
         region = ifelse(region == "Tasman Nelson", yes = "Tasman/Nelson", no = region))


cultures_weights <- 
  cultures %>% 
  group_by(year) %>% 
  mutate(weight = gdp / sum(gdp)) %>% 
  select(-gdp) %>% 
  mutate(region = as.character(region))



cultures_weights %>% 
  group_by(region) %>% 
  summarise(poids = mean(weight) * 100,
            poids = round(poids, 2))


# LOADING WEATHER STATIONS DATA #
# ----------------------------- #

#' charger_donnees_mesure
#' @param dossier (string) : file containing data of a given weather measure
#' dossier <- "data_66"
charger_donnees_mesure <- function(dossier){
  N <-list.files(dossier, full.names = TRUE)
  N <- N[str_detect(N, "rda$")]
  df <- lapply(N, function(x){
    load(x)
    res
  })
  
  df <- 
    df %>% bind_rows()
  
  # Keep only observations from stations with at least 20 years of recording
  stations_to_keep <- 
    df %>% 
    group_by(Station) %>% 
    summarise(nb = n()) %>% 
    filter(nb >= 12*20) %>% 
    .$Station
  
  df %>% 
    filter(Station %in% stations_to_keep)
}# End of charger_donnees_mesure()


df_00 <- charger_donnees_mesure("data_00")
df_66 <- charger_donnees_mesure("data_66")



# Vector of every month between 1980 and 2015
v_dates <- 
  str_c(month.abb,
        "-",
        seq(1980, 2015) %>% 
          rep(each = 12))


# ================================= #
# NUMBER OF STATIONS FOR EACH MONTH #
# ================================= #

#' mise_en_forme_rapide
#' @param code (string) : measure code (e.g. "00" for rainfall)
mise_en_forme_rapide <- function(code){
  df <- get(str_c("df_", code))
  stations_mesure <- stations_all[[str_c("stations_", code)]]$agent
  df %>% 
    rename(agent = Station, date = `Mon-YYYY(local)`,
           code = `Stat Code`, value = `Stat Value `) %>% 
    mutate(value = as.numeric(value),
           year = str_sub(date, -4),
           month = str_sub(date, 1, 3)) %>% 
    left_join(codes) %>% 
    left_join(stations %>% 
                filter(agent %in% stations_mesure) %>% 
                select(agent, long, lat, region) %>% 
                mutate(agent = as.character(agent))) %>% 
    select(-`Day of Extr`, -code, -date) %>% 
    mutate(year = as.numeric(year))
}# End of mise_en_forme_rapide()


df_plot_stations <- 
  mise_en_forme_rapide("00") %>% 
  bind_rows(mise_en_forme_rapide("66"))

df_plot_stations <- 
  df_plot_stations %>% 
  mutate(date = str_c(year,
                      "-",
                      sprintf("%02s", match(month, month.abb)),
                      "-15"),
         date = as.Date(date))

df_plot_stations <- 
  df_plot_stations %>% 
  filter(date < as.Date("2017-01-01"))


library(scales)
source("../variables_names.R")

if(save_graphs){

p <- 
  ggplot(data = 
           df_plot_stations %>% 
           group_by(date, variable) %>% 
           summarize(nb_obs = n()) %>% 
           ungroup(),
         aes(x = date, y = nb_obs, linetype = variable, colour = variable)) +
  geom_line() +
  scale_x_date(breaks = date_breaks("2 year"), labels = date_format("%Y")) +
  xlab("") + ylab("") +
  scale_linetype_discrete("",
                          labels = c("rainfall" = "Total Rainfall",
                                     "sm_mean" = "Mean Deficit Of Soil Moisture")) +
  scale_colour_discrete("",
                        labels = c("rainfall" = "Total Rainfall",
                                   "sm_mean" = "Mean Deficit Of Soil Moisture")) +
  theme_paper()

p_1 <- p +
  theme(legend.direction = "vertical",
        legend.key.height	= unit(2, "line"),
        legend.key.width	= unit(3, "line"))

width <- 20
ggsave(p_1,
       file = "../../images/nb_stations_date.pdf", width = width, height=.5*width)


# Only with Soil Moisture deficit
p <- 
  ggplot(data = 
           df_plot_stations %>% 
           filter(variable == "sm_mean") %>% 
           group_by(date) %>% 
           summarize(nb_obs = n()) %>% 
           ungroup(),
         aes(x = date, y = nb_obs)) +
  geom_line(colour = "#0081BC", size = 2.5) +
  scale_x_date(breaks = date_breaks("4 year"), labels = date_format("%Y")) +
  xlab("") + ylab("") +
  theme_paper()

width <- 20
# ggsave(p,
#        file = "../../images/nb_stations_date_sm.pdf", width = width, height=.4*width)

library(plotRTeX)
#source("../export_tex.R")
width <- 7
ggplot2_to_pdf(plot = p, path = "../../images/",
               filename = "nb_stations_date_sm",
               width = width, height = width)

}

# ================== #
# STATIONS LOCATIONS #
# ================== #
if(save_graphs){
p <- 
  ggplot() +
  geom_polygon(data = nz_df_regions, aes(x = long, y = lat, group = group)) +
  geom_point(data = stations, aes(x = long, y = lat, colour = region), size = .9) +
  scale_colour_discrete("") +
  coord_quickmap() +
  scale_y_continuous(breaks = seq(-90, 90, by = 5)) +
  scale_x_continuous(breaks = seq(-180, 180, by = 5)) +
  theme(text = element_text(size = 10),
        panel.background = element_rect(fill = NA),
        panel.border = element_rect(fill = NA, colour = "grey60", size = 1),
        axis.line = element_line(colour = "grey60"),
        axis.title = element_blank(),
        axis.text = element_text(), 
        #axis.ticks = element_blank(), axis.line = element_blank(),
        legend.text = element_text(size = rel(1.4)),
        legend.title = element_text(size = rel(1.4)),
        legend.background = element_rect(),
        legend.key.height	= unit(2, "line"),
        legend.key.width	= unit(3, "line"),
        #legend.position = "bottom", 
        #legend.direction = "horizontal", legend.box = "vertical",
        panel.spacing = unit(1, "lines"),
        panel.grid.major = element_line(colour = "grey90"), 
        #panel.grid.minor = element_line(colour = "grey90"),
        panel.grid.minor = element_blank(),
        plot.margin = unit(c(1, 1, 1, 1), "lines"),
        strip.text = element_text(size = rel(1.2)))
p

# width <- 20
# ggsave(p,
#        file = "../../images/stations_loc.pdf", width = width, height=0.6*width)

library(plotRTeX)
#source("../export_tex.R")
width <- 7
ggplot2_to_pdf(plot = p, path = "../../images/",
               filename = "stations_loc",
               width = width, height = width)

}

# ===================== #
# VALUE FOR EACH REGION #
# ===================== #


quarters <- 
  cbind(month = c("Jan", "Feb", "Mar",
                  "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep",
                  "Oct", "Nov", "Dec"),
        quarter = rep(1:4, each = 3)) %>% 
  data.frame(stringsAsFactors = FALSE)

# Returns a list of two elements:
# - weighted_values: weighted values of the measure by month and year
# - weighted_values_q: weighted values of the measure by month
# Weights are computed as the share of agricultural gdp in the region
# @code (string) : numero de la mesure (e.g. "00" pour rainfall)
# code <- "66"
mise_en_forme_mesure <- function(code){
  df <- get(str_c("df_", code))
  stations_mesure <- stations_all[[str_c("stations_", code)]]$agent
  df <- 
    df %>% 
    rename(agent = Station, date = `Mon-YYYY(local)`,
           code = `Stat Code`,
           value = `Stat Value `) %>% 
    mutate(value = as.numeric(value),
           year = str_sub(date, -4),
           month = str_sub(date, 1, 3),
           code = as.character(code)) %>% 
    left_join(codes) %>% 
    left_join(stations %>% 
                filter(agent %in% stations_mesure) %>% 
                select(agent, long, lat, region) %>% 
                mutate(agent = as.character(agent))) %>% 
    select(-`Day of Extr`, -code, -date) %>% 
    mutate(year = as.numeric(year))
  #%>% 
  #  left_join(cultures_weights)
  
  # Weights
  cultures <- read_excel("../economic_data/matrix_pond_agriculture.xls", sheet="RNA434201_20150707_091730_92", skip = 2)
  colnames(cultures)[1] <- "year"
  cultures <- cultures[-1,]
  cultures <- cultures[, seq(1, which(colnames(cultures) == "New Zealand")-1)]
  cultures <- cultures[seq(1, which(str_detect(cultures$year, "Table information:"))-1),]
  cultures <- apply(cultures, 2, as.numeric) %>% data.frame() %>% tbl_df()
  cultures <-
    cultures %>% 
    gather(region, gdp, -year) %>% 
    mutate(year = as.numeric(year))
  
  cultures <- 
    cultures %>% 
    mutate(region = str_replace_all(region, "\\.", " "),
           region = ifelse(region == "Hawke s Bay", yes = "Hawke's Bay", no = region),
           region = ifelse(region == "Manawatu Wanganui", yes = "Manawatu-Wanganui", no = region),
           region = ifelse(region == "Tasman Nelson", yes = "Tasman/Nelson", no = region))
  
  
  cultures_weights <- 
    cultures %>% 
    filter(region %in% df$region) %>% 
    group_by(year) %>% 
    mutate(weight = gdp / sum(gdp)) %>% 
    select(-gdp) %>% 
    mutate(region = as.character(region))
  
  # Average of the last 5 years
  years_weights <- unique(cultures_weights$year) %>% sort
  years_weights <- years_weights[(length(years_weights)-4):length(years_weights)]
  cultures_weights_last <- cultures_weights %>% 
    filter(year %in% years_weights) %>% 
    group_by(region) %>% 
    summarise(weight = mean(weight))
  
  # Missing years
  a_completer <- unique(df$year)[!unique(df$year) %in% cultures_weights$year]
  a_completer <- a_completer[a_completer > 2015]
  
  # Region names
  regions_cult <- unique(cultures_weights$region)
  
  cultures_weights <- 
    cultures_weights %>% 
    bind_rows(
      expand.grid(a_completer, regions_cult) %>% 
        rename(year = Var1, region = Var2) %>% 
        left_join(cultures_weights_last)
    )
  
  df <- 
    df %>% 
    left_join(cultures_weights)
  
  df %>% 
    left_join(quarters) %>% 
    mutate(month = factor(month, levels = month.abb))
  
}# End of mise_en_forme_mesure()


