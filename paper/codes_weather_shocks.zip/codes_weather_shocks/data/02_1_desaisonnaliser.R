# Codes to replicate the content of the article:
# "Weather Shocks
# 2019


# Objective : remove seasonal component of time-series

library(seasonal)
library(dplyr)
library(dplyrExtras)
library(stringr)
library(zoo)


# Desaisonnalisation
desaison <- function(df, nom, start, freq = 4){
  df %>% 
    s_select(nom) %>% 
    ts(start = start, frequency = freq) %>% 
    seas()
}




# Extraire les composantes de temps de l'objet ts
extraire_temps <- function(x){
  annees <- 
    x %>% 
    time() %>% 
    as.yearqtr() %>% 
    format("%Y")
  #   mois <- x %>% 
  #     time() %>% 
  #     as.yearmon() %>% 
  #     format("%m") %>% 
  #     as.numeric()
  quarter <-
    x %>% 
    time() %>% 
    as.yearqtr() %>% 
    format("%q")
    
  data.frame(year = annees, quarter = quarter, stringsAsFactors = FALSE)
}

# Transformer l'objet seas en data.frame
seas_to_df <- function(x, name){
  res <- 
    final(x) %>% extraire_temps() %>% 
    bind_cols(data.frame(x = final(x) %>% as.vector()))
  colnames(res)[3] <- name
  res
}

# Desaisonnaliser une serie
desaisonnaliser <- function(df, nom, start){
  seas_to_df(desaison(df = df, nom = nom, start = start), name = nom)
}



