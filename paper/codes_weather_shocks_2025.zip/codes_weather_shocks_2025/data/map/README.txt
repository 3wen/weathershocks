Download and extract a map of NZ
New Zealand 2015 clipped generalised (NZTM) (189MB)
Source: Statistics New Zealand
URL: http://www3.stats.govt.nz/digitalboundaries/annual/ESRI_Geodatabase_2015_Digital_Boundaries_Generalised_Clipped.zip