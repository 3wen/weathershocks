# This file first identify the region associated with each station from its 
# (lon,lat) coordinates.
# Then, it associates a weight to give to each region each year according to 
# the share of agricultural GDP.

library(tidyverse)
library(sf)
library(readxl)

# Set to TRUE to save the graphs
if (!exists("save_graphs")) {
  save_graphs <- FALSE
}
# If save_graphs is TRUE, you will need to have this package installed:
# remotes::install_github("3wen/plotRTex")

# 1. Load Data----

# Map
load("../map/nz_df_regions.rda")
nz_df_regions

# Codes of weather variables
# 00	MTHLY: TOTAL RAIN	Mthly_Stats: Total Rainfall
# 66 	MTHLY: MEAN DEFICIT (WBAL) 	Mthly_Stats: Mean Deficit Of Soil Moisture (Wbal Awc=150mm)
codes <- data.frame(
  code = c("00", "66"),
  variable = c("rainfall", "sm_mean")
)

load("stations_all.rda")
stations <- stations_all |> 
  bind_rows() |> 
  select(agent, long, lat) |> 
  unique()

stations <- st_as_sf(
  stations, coords = c("long", "lat"), remove = FALSE, crs = 4326
)
stations <- st_transform(stations, st_crs(nz_df_regions))


## 1.1 Identify Stations in Each Region----

stations <- st_join(
  stations,
  nz_df_regions[, "region"],
  join = st_within,
  left = TRUE
)


ggplot() +
  geom_sf(
    data = stations,
    mapping = aes(colour = region),
    size = .1
  ) +
  geom_sf(
    data = nz_df_regions,
    fill = NA, colour = "black"
  )

## 1.2 Weather Station Data ----

#' Load weather station data for a single metric
#' 
#' @param folder  Folder containing data of a given weather measure
#' @returns 
#' dossier <- "data_66"
load_data_metrics <- function(folder) {
  
  N <- list.files(folder, full.names = TRUE)
  N <- N[str_detect(N, "rda$")]
  # Loop over each file (one file per year)
  df <- lapply(N, function(x) {
    load(x)
    res
  })
  
  df <- 
    df |> bind_rows()
  
  # Keep only observations from stations with at least 20 years of recording
  stations_to_keep <- 
    df |> 
    count(Station) |> 
    filter(n >= 12 * 20) |>  
    pull("Station")
  
  df |> 
    filter(Station %in% stations_to_keep)
}


df_00 <- load_data_metrics("data_00")
df_66 <- load_data_metrics("data_66")

### Number of Stations for Each Month----


#' Quick reshaping of the data
#' 
#' @param code Measure code (e.g. "00" for rainfall) (string)
#' 
mise_en_forme_rapide <- function(code) {
  
  df <- get(str_c("df_", code))
  stations_mesure <- stations_all[[str_c("stations_", code)]]$agent
  df |> 
    rename(
      agent = Station, date = `Mon-YYYY(local)`,
      code = `Stat Code`, value = `Stat Value `
    ) |> 
    mutate(
      value = as.numeric(value),
      year = str_sub(date, -4),
      month = str_sub(date, 1, 3),
      agent = as.character(agent),
      code = as.character(code)
    ) |> 
    left_join(codes) |> 
    left_join(
      stations |> 
        filter(agent %in% stations_mesure) |> 
        select(agent, long, lat, region) |> 
        mutate(agent = as.character(agent))
    ) |> 
    select(-`Day of Extr`, -code, -date) |> 
    mutate(year = as.numeric(year))
}


df_plot_stations <- 
  mise_en_forme_rapide("00") |> 
  bind_rows(mise_en_forme_rapide("66"))

df_plot_stations <- 
  df_plot_stations |> 
  mutate(
    date = str_c(
      year,
      "-",
      sprintf("%02s", match(month, month.abb)),
      "-15"
    ),
    date = as.Date(date)
  )

df_plot_stations <- 
  df_plot_stations |> 
  filter(date < as.Date("2017-01-01"))


library(scales)
source("../variables_names.R")

if (save_graphs) {
  
  p <- 
    ggplot(
      data = 
        df_plot_stations |> 
        group_by(date, variable) |> 
        summarize(nb_obs = n()) |> 
        ungroup(),
      mapping = aes(x = date, y = nb_obs, linetype = variable, colour = variable)
    ) +
    geom_line() +
    scale_x_date(breaks = date_breaks("2 year"), labels = date_format("%Y")) +
    labs(x = NULL, y = NULL) +
    scale_linetype_discrete(
      "",
      labels = c("rainfall" = "Total Rainfall",
                 "sm_mean" = "Mean Deficit Of Soil Moisture")
    ) +
    scale_colour_discrete(
      "",
      labels = c("rainfall" = "Total Rainfall",
                 "sm_mean" = "Mean Deficit Of Soil Moisture")
    ) +
    theme_paper()
  
  p_1 <- p +
    theme(
      legend.direction = "vertical",
      legend.key.height	= unit(2, "line"),
      legend.key.width	= unit(3, "line")
    )
  
  width <- 20
  ggsave(
    p_1,
    file = "../../images/nb_stations_date.pdf", width = width, height=.5*width
  )
  
  # Only with Soil Moisture deficit
  p <- 
    ggplot(
      data = 
        df_plot_stations |> 
        filter(variable == "sm_mean") |> 
        group_by(date) |> 
        summarize(nb_obs = n()) |> 
        ungroup(),
      aes(x = date, y = nb_obs)) +
    geom_line(colour = "#0081BC", linewidth = 1.2) +
    scale_x_date(breaks = date_breaks("4 year"), labels = date_format("%Y")) +
    labs(x = NULL, y = NULL) +
    theme_paper()
  
  width <- 20
  # ggsave(
  #   p,
  #   file = "../../images/nb_stations_date_sm.pdf", width = width, height=.4*width
  # )
  
  # remotes::install_github("3wen/plotRTex")
  library(plotRTeX)
  #source("../export_tex.R")
  width <- 7
  ggplot2_to_pdf(
    plot = p, path = "../../images/",
    filename = "nb_stations_date_sm",
    width = width, height = width
  )
  
}

### Station Locations----

if (save_graphs) {
  p <- 
    ggplot() +
    geom_sf(
      data = nz_df_regions
    ) +
    geom_sf(
      data = stations,
      mapping = aes(colour = region),
      size = .1
    ) +
    scale_colour_discrete("") +
    scale_y_continuous(breaks = seq(-90, 90, by = 5)) +
    scale_x_continuous(breaks = seq(-180, 180, by = 5)) +
    theme(
      text = element_text(size = 10),
      panel.background = element_rect(fill = NA),
      panel.border = element_rect(fill = NA, colour = "grey60", linewidth = 1),
      axis.line = element_line(colour = "grey60"),
      axis.title = element_blank(),
      axis.text = element_text(), 
      legend.text = element_text(size = rel(1.4)),
      legend.title = element_text(size = rel(1.4)),
      legend.background = element_rect(),
      legend.key.height	= unit(2, "line"),
      legend.key.width	= unit(3, "line"),
      panel.spacing = unit(1, "lines"),
      panel.grid.major = element_line(colour = "grey90"), 
      panel.grid.minor = element_blank(),
      plot.margin = unit(c(1, 1, 1, 1), "lines"),
      strip.text = element_text(size = rel(1.2))
    )
  p
  
  # width <- 20
  # ggsave(
  #   p,
  #   file = "../../images/stations_loc.pdf", width = width, height=0.6*width
  # )
  
  library(plotRTeX)
  #source("../export_tex.R")
  width <- 7
  ggplot2_to_pdf(
    plot = p, path = "../../images/",
    filename = "stations_loc",
    width = width, height = width
  )
  
}

### Value for Each Region----

quarters <- 
  tibble(
    month = c("Jan", "Feb", "Mar",
              "Apr", "May", "Jun",
              "Jul", "Aug", "Sep",
              "Oct", "Nov", "Dec"),
    quarter = rep(1:4, each = 3)
  )

#' Reshape Metrics
#' 
#' @param code Code number of the metric (e.g., "00" for rainfall)
#' 
#' @returns A list of two elements:
#' * `weighted_values`: weighted values of the measure by month and year
#' * `weighted_values_q`: weighted values of the measure by month
#' @details
#' Weights are computed as the share of agricultural gdp in the region
#' 
#' code <- "66"
shape_metric <- function(code) {
  df <- get(str_c("df_", code))
  # Focus on the stations that give values for that metric
  stations_mesure <- stations_all[[str_c("stations_", code)]]$agent
  df <- 
    df |> 
    rename(
      agent = Station, date = `Mon-YYYY(local)`,
      code = `Stat Code`,
      value = `Stat Value `
    ) |> 
    mutate(
      value = as.numeric(value),
      year = str_sub(date, -4),
      month = str_sub(date, 1, 3),
      code = as.character(code),
      agent = as.character(agent)
    ) |> 
    left_join(codes) |> 
    left_join(
      stations |> 
        filter(agent %in% stations_mesure) |> 
        select(agent, long, lat, region) |> 
        mutate(agent = as.character(agent))
    ) |> 
    select(-`Day of Extr`, -code, -date) |> 
    mutate(year = as.numeric(year))
  
  # Weights
  cultures <- read_excel("../economic_data/matrix_pond_agriculture.xls", sheet="RNA434201_20150707_091730_92", skip = 2)
  colnames(cultures)[1] <- "year"
  cultures <- cultures[-1,]
  cultures <- cultures[, seq(1, which(colnames(cultures) == "New Zealand")-1)]
  cultures <- cultures[seq(1, which(str_detect(cultures$year, "Table information:"))-1),]
  cultures <- apply(cultures, 2, as.numeric) %>% data.frame() %>% as_tibble()
  cultures <-
    cultures |> 
    gather(region, gdp, -year) |> 
    mutate(year = as.numeric(year))
  
  cultures <- 
    cultures |> 
    mutate(
      region = str_replace_all(region, "\\.", " "),
      region = ifelse(region == "Hawke s Bay", yes = "Hawke's Bay", no = region),
      region = ifelse(region == "Manawatu Wanganui", yes = "Manawatu-Wanganui", no = region),
      region = ifelse(region == "Tasman Nelson", yes = "Tasman/Nelson", no = region)
    )
  
  
  cultures_weights <- 
    cultures |> 
    filter(region %in% df$region) |> 
    group_by(year) |> 
    mutate(weight = gdp / sum(gdp)) |> 
    select(-gdp) |> 
    mutate(region = as.character(region))
  
  # Average of the last 5 years
  years_weights <- unique(cultures_weights$year) |> sort()
  years_weights <- years_weights[(length(years_weights)-4):length(years_weights)]
  cultures_weights_last <- cultures_weights |> 
    filter(year %in% years_weights) |> 
    group_by(region) |> 
    summarise(weight = mean(weight))
  
  # Missing years
  a_completer <- unique(df$year)[!unique(df$year) %in% cultures_weights$year]
  a_completer <- a_completer[a_completer >= 2015]
  
  # Region names
  regions_cult <- unique(cultures_weights$region)
  
  cultures_weights <- 
    cultures_weights |> 
    bind_rows(
      expand.grid(year = a_completer, region = regions_cult) |> 
        left_join(cultures_weights_last)
    )
  
  df <- 
    df |> 
    left_join(cultures_weights)
  
  df |> 
    left_join(quarters) |> 
    mutate(month = factor(month, levels = month.abb))
  
}
