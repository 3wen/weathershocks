library(tidyverse)
# install.packages("spi")

# Set to TRUE to save the graphs
save_graphs <- FALSE

# If not already executed, this script needs to be run
source("02_1_rassembler_help.R")


# The following function (`valeur_c()`) is used afterwards to create an index 
# of drought. It is from the following paper:
# Narasimhan, B., & Srinivasan, R. (2005). 
# Development and evaluation of Soil Moisture Deficit Index (SMDI) 
# and Evapotranspiration Deficit Index (ETDI) for agricultural drought monitoring.
# Agricultural and Forest Meteorology, 133(1), 69-88.
val_T <- 1
valeur_c <- function(t) -25 / (25 * t + 25)

#' @param code_variable Code of the weather variable (e.g., "00" for rainfall).
#' @param stations_mean (Logical) Computation of the SMDI at the station level
#'  (if `TRUE`) or at the region level (if `FALSE`, default value).
#' @param val_T Temporal scaling or smoothing constant (default to `1`).
#' 
#' code_variable <- "66" ; num_station = NULL ; stations_mean = FALSE
climate_variables <- function(code_variable, 
                              stations_mean = FALSE, 
                              val_T = 1) {
  # Retrieve data
  df <- shape_metric(code_variable)
  # Remove observation from weather stations too close to the coastal area
  df <- df |> filter(!is.na(region))
  
  # Perform region-wise aggregations: 
  # the value from monthly data at station are averaged at the 
  # region x year x month level
  df <-
    df |> 
    group_by(variable, region, weight, year, quarter, month) |> 
    summarize(value = mean(value, na.rm = TRUE)) |> 
    ungroup() |> 
    arrange(year, month)
  
  # Long term statistics for each region
  df_lt <- 
    df |> 
    group_by(variable, region, month) |> 
    summarise(
      value_mean = mean(value),
      value_med = median(value),
      value_min = min(value),
      value_max = max(value),
      value_sd = sd(value)
    )
  
  # Strandardization
  df <- 
    df |> 
    left_join(df_lt) |> 
    mutate(
      value_s = ifelse(
        value <= value_med,
        yes = (value - value_med)/(value_med - value_min) * 100,
        no = (value - value_med)/(value_max - value_med) * 100
      ),
      value_demeaned = value / value_mean,
      value_pct = 100*(value - value_mean) / value_mean,
      value_norm = (value - value_mean) / value_sd
    )
  
  # Index creation
  # SMDI
  # SD_{ij} = \frac{SW_{ij} - Med(SW_{j})}{Med(SW_{j})}, j = month, i = year
  # Init:
  # SMDI_{1} = SD_1 / 50
  # Reason:
  # SMDI_{j} = 0.5 * SMDI_{j-1} + \frac{SD_j}/50
  
  # Help function to compute the index for a station or a region
  # @x: a station id if stations_mean, a region id otherwise
  # x <- unique(df$region)[1]
  calcul_smdi <- function(x) {
    
    if (stations_mean) {
      df_tmp <- 
        df |> 
        filter(agent == x)
    } else {
      df_tmp <- 
        df |>  
        filter(region == x)
    }
    
    index <- rep(NA, nrow(df_tmp))
    # Init the recursive formula
    index[1] <- df_tmp$value_s[1] / (25 * val_T + 25)
    # i <- 1
    for (i in 2:nrow(df_tmp)) {
      index[i] <- df_tmp$value_s[i]/(25*val_T + 25)  - valeur_c(val_T)*index[i-1]
    }
    df_tmp$index <- index
    df_tmp
  }
  
  if (stations_mean) {
    df <- lapply(unique(df$agent), calcul_smdi) |> 
      bind_rows()
  } else {
    df <- lapply(unique(df$region), calcul_smdi) |>  
      bind_rows()
  }
  
  
  # SPI index for each region
  calcul_spi <- function(x) {
    
    if (stations_mean) {
      df_tmp <- 
        df |> 
        filter(agent == x)
    } else {
      df_tmp <- 
        df |> 
        filter(region == x)
    }
    
    
    # Build a ts object with frequency = 12
    df_tmp <- df_tmp |> arrange(year, month)
    start_year  <- df_tmp$year[1]
    start_month <- df_tmp$month[1]
    
    smdi_val <- ts(
      df_tmp$value, start = c(start_year, start_month), frequency = 12
    )
    spei_fit <- SPEI::spi(data = smdi_val, scale = 3, verbose = FALSE)
    spei_val <- as.numeric(spei_fit$fitted)
    
    df_tmp_spi <- df_tmp |> 
      select(year, month) |> 
      mutate(
        spi = spei_val
      )
    
    if (stations_mean) {
      df_tmp_spi <- 
        df_tmp_spi |> 
        mutate(agent = x)
    } else {
      df_tmp_spi <- 
        df_tmp_spi |> 
        mutate(region = x)
    }
    
    df_tmp_spi
  }
  
  
  if (stations_mean) {
    df_smpi <- lapply(unique(df$agent), calcul_spi) |> 
      bind_rows() |> 
      as_tibble()
  } else {
    df_smpi <- lapply(unique(df$region), calcul_spi) |> 
      bind_rows() |> 
      as_tibble()
  }
  
  df <- 
    df |> 
    left_join(df_smpi)
  
  # Removing data where no weight is available
  df <- df |> filter(!is.na(weight))
  
  # Weighted values
  df <- 
    df |> 
    ungroup() |> 
    mutate(
      value = value * weight,
      value_spi = spi * weight,
      index = index * weight,
      value_demeaned = value_demeaned * weight,
      value_pct = value_pct * weight,
      value_norm = value_norm * weight
    ) |> 
    group_by(variable, year, quarter, month) |> 
    summarize(
      value = sum(value),
      spi = sum(value_spi),
      index = sum(index),
      value_demeaned = sum(value_demeaned),
      value_pct = sum(value_pct),
      value_norm = sum(value_norm)
    ) |> 
    ungroup()
  
  
  df
}


# Soil Moisture
df_sm <- climate_variables("66")
# Rainfall
df_rainfall <- climate_variables("00")

# Gathering different climatic variables in a single data.frame
df_meteo_month <- 
  df_sm |> 
  bind_rows(df_rainfall) |> 
  left_join(codes)

# Quarterly aggregation
df_meteo <- 
  df_meteo_month |> 
  group_by(variable, year, quarter) |> 
  summarize(
    value = mean(value, na.rm = TRUE),
    spi = mean(spi, na.rm = TRUE),
    index = mean(index, na.rm = TRUE),
    value_demeaned = mean(value_demeaned, na.rm = TRUE),
    value_pct = mean(value_pct, na.rm = TRUE),
    value_norm = mean(value_norm, na.rm = TRUE)
  )

# Export Results----


meteo <- 
  df_meteo |> 
  mutate(
    value = round(value, 4),
    index = round(index, 4),
    spi = round(spi, 4),
    valuedemeaned = round(value_demeaned, 4),
    valuepct = round(value_pct, 4),
    valuenorm = round(value_norm, 4)
  ) |> 
  select(-value_demeaned, -value_pct, -value_norm) |> 
  unite(val_ind, value, index, spi, valuedemeaned, valuepct, valuenorm, sep = "_") |> 
  spread(variable, val_ind) |> 
  gather(variable, val_ind, -year, -quarter) |> 
  separate(
    val_ind, 
    c("value", "index", "spi", "valuedemeaned", "valuepct", "valuenorm"), 
    sep = "_"
  ) |> 
  gather(type, value, value, index, spi, valuedemeaned, valuepct, valuenorm) |> 
  mutate(
    date = year + as.numeric(as.character(quarter))/4 - 0.25,
    value = as.numeric(value)
  ) |> 
  unite(var, variable, type, sep = "_") |> 
  spread(var, value) |> 
  rename(
    YEARS = date,
    rain_val = rainfall_valuedemeaned,
    soil_moist = sm_mean_valuedemeaned,
    soil_moist_norm = sm_mean_valuenorm,
    crfi = rainfall_index,
    smdi = sm_mean_index,
    spi = rainfall_spi
  ) |> 
  select(-sm_mean_spi)


save(meteo, file = "meteo.rda")

