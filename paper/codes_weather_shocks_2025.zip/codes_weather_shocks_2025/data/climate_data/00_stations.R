# This file: Get stations of interest

# Note in 2025, the "CliFlo" service is no longer available.
# The replacement tool is DataHub: https://data.niwa.co.nz/collections/all
# The following codes no longer work and should be adapted.

library(readr)
library(dplyr)
library(lubridate)
library(stringr)

# Functions ----

#' Import weather data from a CSV file.
#' 
#' @param file Full path to the file to import.
#' @returns A tibble with the data:
#" * `agent`: the identifier of the weather station.
#" * `network`: network.
#" * `start_date`: Start date of the weather station.
#" * `end_date`: End date of the weather station.
#" * `pct_complete`: Percentage of days with observations.
#" * `name`: Name of the weather station.
#" * `lat`: Latitude of the weather station (in degrees).
#" * `long`: Longitude of the weather station (in degrees).
#' @md
#' 
import_weather_station <- function(file) {
  
  df <- read.csv(file, skip = 6, sep = "\t")
  df <- df[-which(str_detect(df$Agent, "Numbe")), ]
  df <- as_tibble(df)
  
  df <- 
    df |> 
    rename(
      agent = Agent,
      network = Network,
      start_date = Start_Date,
      end_date = End_Date,
      pct_complete = Percent_Complete,
      name = Name,
      lat = `Lat.dec_deg.`,
      long = `Long.dec_deg.`
    ) |> 
    mutate(
      start_date = dmy(start_date, locale = "en_us"),
      end_date = dmy(end_date, locale = "en_us")
    )
  
  df
}

#' Import weather station data from all the files contained in a folder.
#' 
#' @param folder Folder name (string).
#' @param save If `TRUE` (default), the data table is saved as an rda file in 
#'  the current working directory (which is assumed to be `data/climate_data`).
#'  The file name is set as the name of the folder that contains the imported
#'  data.
#' 
#' @returns A tibble with the variable of interest that is mentioned by the 
#' folder name.
#' @examples
#' stations_66 <- stations_to_df("stations_66")
#' 
stations_to_df <- function(folder, save = TRUE) {
  
  # The files to loop over
  N <- list.files(folder, full.names = TRUE)
  
  stations <- lapply(N, import_weather_station)
  stations <- bind_rows(stations)
  stations <- unique(stations)
  
  # Remove stations that closed prior to 1980
  stations <- 
    stations |> 
    filter(year(end_date) >= 1980)
  save(stations, file = str_c(folder, ".rda"))
  
  stations
}

# Import Data----

# 00	MTHLY: TOTAL RAIN	Mthly_Stats: Total Rainfall
# 02	MTHLY: MEAN TEMP	Mthly_Stats: Mean Air Temperature; 0.5* (Max + Min)
# 66 	MTHLY: MEAN DEFICIT (WBAL) 	Mthly_Stats: Mean Deficit Of Soil Moisture (Wbal Awc=150mm)
# 69	MTHLY: MEAN SOIL MOISTURE %	Mthly_Stats: Mean Soil Moisture Percent At 20cm Depth
# 74 	MTHLY: DAYS OF DEFICIT (WBAL) 	Mthly_Stats: Days Of Deficit (Wbal Awc=150mm)
codes <- data.frame(
  code = c("00", "02", "66", "69", "74"),
  variable = c("rainfall", "temperature", "sm_mean", "sm_pct", "sm_def_days")
)

# Total Rainfall
stations_00 <- stations_to_df(folder = "stations_00")
# Mean Deficit Of Soil Moisture
stations_66 <- stations_to_df("stations_66")

stations_all <- list(
  stations_00 = stations_00,
  stations_66 = stations_66
)

save(stations_all, file = "stations_all.rda")


#' Identify all the stations that operate in a given year.
#' 
#' @param year Year of interest (integer).
#' @param stations Name of the tibble (e.g., "stations_00")
#' 
#' @returns A vector of strings with the IDs (`agent`) of the weather stations.
#' @examples
#' year <- 2015 ; stations <-  "stations_02"
#' stations_year(year = year, stations = stations)
#' 
stations_year <- function(year, stations) {
  stations <- get(stations)
  stations |> 
    filter(year(start_date) <= !!year, year(end_date) >= !!year) |> 
    pull("agent") |> 
    unique()
}


# Helper function to download data from The National Climate Database.
source("01_1_recuperer_data.R")

lien <- "http://cliflo.niwa.co.nz/pls/niwp/wa.logindb"
curl = getCurlHandle()
curlSetOpt(
  cookiejar="cookies.txt",  
  useragent = "Mozilla/5.0", 
  followlocation = TRUE, 
  curl = curl
)
login <- postForm(
  uri = lien, .opts = curlOptions(followlocation=TRUE), curl = curl,
  cusername = "egallic",# put your username here
  cpwd = "YT0Z2PE0", # put your password here
  submit = "login",
  ispopup = "false",
  ispopup = "false"
)

# From the results obtained from the sent request
# returns the information as a tbl_df
mettre_en_forme_res <- function(df_tmp) {
  df_tmp <- str_split(df_tmp, "\n")[[1]]
  
  if(any(str_detect(df_tmp, "No rows\\? See this help link"))) {
    # Nothing to return
    res <- NULL
  } else {
    ind_deb <- which(str_detect(df_tmp, "^Station,Mon-YYYY"))
    ind_fin <- which(str_detect(df_tmp, "^UserName is = ")) - 2
    df_tmp <- df_tmp[ind_deb:ind_fin]
    df_tmp <- str_replace(df_tmp, "\r$", "")
    
    noms_variables <- str_split(df_tmp[1], ",")[[1]]
    
    head(do.call("rbind", str_split(df_tmp[-1], ",")))
    
    res <- do.call("rbind", str_split(df_tmp[-1], ",")) |> 
      data.frame() |> 
      as_tibble() |> 
      select(-X6)
    colnames(res) <- noms_variables[-6]
  }
  
  res
}

#' Splits a vector in subsets of desired length
#' 
#' @param x Vector of observations to split
#' @param n Maximum length of the subsets.
#' @details
#' The last subset may be smaller.
#' 
split_max_groupsize <- function(x, n) {
  split(x, gl(ceiling(length(x) / n), n, length(x)))
}

#' Obtain data for the stations, for a specific year
#' @param year Year (int).
#' @param stations Name of the weather station tibble (string).
#' 
#' year <- 1980 ; stations <- "stations_00"
recup_annee <- function(year, stations) {
  stations_name <- stations
  stations <- get(stations_name) # get the tibble of that name
  prm1 <- str_split(stations_name, "_")[[1]][2] # variable code
  # Identify the stations that operate that year (IDs)
  stations_cour <- stations_year(year = year, stations = stations_name)
  # Split the vector of IDs in subsets of 50.
  a_parcourir <- split_max_groupsize(stations_cour, 50)
  # i <- 1
  for (i in 1:length(a_parcourir)) {
    df_tmp <- data_stations(stations = a_parcourir[[i]], year = year, prm1 = prm1)
    if(!dir.exists(str_c("data_", prm1))) dir.create(str_c("data_", prm1))
    if(!dir.exists(str_c("data_", prm1, "/raw"))) dir.create(str_c("data_", prm1, "/raw"))
    
    save(df_tmp, file = str_c("data_", prm1, "/raw/", annee, "_", sprintf("%02s", i), ".rda"))
    res <- mettre_en_forme_res(df_tmp)
    save(res, file = str_c("data_", prm1, "/", annee, "_", sprintf("%02s", i), ".rda"))
    rm(df_tmp, res)
  }
}

# stations_cour <- stations_annee(2010)
# a_parcourir <- split_max_groupsize(stations_cour, 20)
# cat(a_parcourir[[5]], sep = ",")

for(a in 1980:2015) recup_annee(a, "stations_00")
for(a in 1987:2015) recup_annee(a, "stations_66")

